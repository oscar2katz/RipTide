"""
RIPTIDE v5, big universe test of the gap and hold drift (part of Ocean Outlays)

v4 found a maybe edge. Buy a stock at the close of a day it gapped up
4 percent or more on double volume and held the move, then hold about
10 days. But it only used 211 popular stocks, which are today's winners.
This retests the long side on every NYSE, Nasdaq and AMEX stock Alpaca
has, including ones that crashed or got delisted, so the answer is honest.

How to run
    New cell, same notebook. Add your keys, run it again and again until
    it says all done. Each run does a slice of the stocks and saves
    progress. It only keeps the gap events, not all the prices, so the
    iPad doesn't run out of memory.
"""

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
START = "2019-11-01"
CHUNK = 100               # stocks per request
CHUNKS_PER_RUN = 10
GAP_MIN = 0.04
VOLUME_MULT = 2.0
MIN_PRICE = 5.0
MIN_DOLLAR_VOL = 5e6      # skip stocks too thin to trade, 5 million dollars a day
HOLDS = [1, 3, 5, 10, 20]
COST_PER_TRADE = 0.0010

UNIVERSE_FILE = "riptide5_universe.txt"
EVENTS_FILE = "riptide5_events.csv"
MARKET_FILE = "riptide5_market.csv"
PROGRESS_FILE = "riptide5_progress.txt"
OLD_LIST_FILE = "riptide3_daily.csv"    # used only to compare against v4's 211 stocks


def call(url):
    req = urllib.request.Request(url, headers={
        "APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET})
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=90) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(30)
                continue
            raise RuntimeError(f"Alpaca said {e.code} {e.read().decode()[:200]}")
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt == 4:
                raise
            time.sleep(15 * (attempt + 1))
    raise RuntimeError("Alpaca kept saying slow down, wait a minute and run again")


def universe():
    if os.path.exists(UNIVERSE_FILE):
        return open(UNIVERSE_FILE).read().split()
    print("getting the full stock list (one time only)...")
    syms = set()
    for status in ("active", "inactive"):
        rows = call("https://paper-api.alpaca.markets/v2/assets?"
                    + urllib.parse.urlencode({"status": status, "asset_class": "us_equity"}))
        for a in rows:
            s = a["symbol"]
            if a.get("exchange") in ("NYSE", "NASDAQ", "AMEX") and s.isalpha() and len(s) <= 5:
                syms.add(s)
    syms = sorted(syms)
    if not syms:
        raise RuntimeError("Alpaca returned no stocks, check the keys and try again")
    open(UNIVERSE_FILE, "w").write("\n".join(syms))
    print(f"  {len(syms)} stocks")
    return syms


def daily(symbols):
    rows, token = [], None
    while True:
        q = {"symbols": ",".join(symbols), "timeframe": "1Day", "start": START,
             "limit": 10000, "adjustment": "all", "feed": "sip"}
        if token:
            q["page_token"] = token
        data = call("https://data.alpaca.markets/v2/stocks/bars?" + urllib.parse.urlencode(q))
        for sym, bars in (data.get("bars") or {}).items():
            for b in bars:
                rows.append((sym, b["t"][:10], b["o"], b["c"], b["v"]))
        token = data.get("next_page_token")
        if not token:
            break
    df = pd.DataFrame(rows, columns=["sym", "day", "o", "c", "v"])
    df["day"] = pd.to_datetime(df["day"])
    return df.drop_duplicates(["day", "sym"])


def process(df):
    """Turn one slice of prices into gap events plus market totals."""
    O = df.pivot(index="day", columns="sym", values="o").sort_index()
    C = df.pivot(index="day", columns="sym", values="c").reindex(O.index)
    V = df.pivot(index="day", columns="sym", values="v").reindex(O.index)
    prev_c = C.shift(1)
    dollar = (C * V).rolling(20, min_periods=10).mean().shift(1)
    liquid = (prev_c >= MIN_PRICE) & (dollar >= MIN_DOLLAR_VOL)

    ret = (C / prev_c - 1).clip(-0.5, 0.5).where(liquid)
    market = pd.DataFrame({"ret_sum": ret.sum(axis=1), "n": ret.notna().sum(axis=1)})

    gap = O / prev_c - 1
    move = C / prev_c - 1
    avg_vol = V.rolling(20, min_periods=10).mean().shift(1)
    sig = liquid & (gap >= GAP_MIN) & (move >= GAP_MIN) & (V >= VOLUME_MULT * avg_vol)

    Cf = C.ffill()            # if a stock is delisted, the trade exits at its last price
    events = []
    for (day, sym) in sig[sig].stack().index:
        i = O.index.get_loc(day)
        row = {"day": day, "sym": sym, "entry": C.at[day, sym], "gap": gap.at[day, sym],
               "dollar_vol": dollar.at[day, sym],
               "next_open": O.iat[i + 1, O.columns.get_loc(sym)] if i + 1 < len(O) else np.nan}
        for h in HOLDS:
            row[f"exit_{h}"] = Cf.iat[i + h, Cf.columns.get_loc(sym)] if i + h < len(Cf) else np.nan
        events.append(row)
    return pd.DataFrame(events), market


def run():
    syms = universe()
    chunks = [syms[i:i + CHUNK] for i in range(0, len(syms), CHUNK)]
    done = int(open(PROGRESS_FILE).read()) if os.path.exists(PROGRESS_FILE) else 0
    if done >= len(chunks):
        return 0, len(chunks)
    print(f"{len(chunks) - done} slices left, doing up to {CHUNKS_PER_RUN} now")
    for k in range(done, min(done + CHUNKS_PER_RUN, len(chunks))):
        df = daily(chunks[k])
        if not df.empty:
            ev, mk = process(df)
            if len(ev):
                ev.to_csv(EVENTS_FILE, mode="a", header=not os.path.exists(EVENTS_FILE), index=False)
            mk.to_csv(MARKET_FILE, mode="a", header=not os.path.exists(MARKET_FILE))
        open(PROGRESS_FILE, "w").write(str(k + 1))
        print(f"  slice {k + 1} of {len(chunks)} done")
    return len(chunks) - min(done + CHUNKS_PER_RUN, len(chunks)), len(chunks)


def tscore(x, days):
    by_day = x.groupby(days).mean()
    return by_day.mean() / by_day.std() * np.sqrt(len(by_day))


def report():
    if not os.path.exists(EVENTS_FILE):
        print("no events yet")
        return
    ev = pd.read_csv(EVENTS_FILE, parse_dates=["day"])
    mk = pd.read_csv(MARKET_FILE, parse_dates=["day"]).groupby("day").sum()
    mret = (mk.ret_sum / mk.n.replace(0, np.nan)).fillna(0)
    midx = (1 + mret).cumprod()
    old = set(pd.read_csv(OLD_LIST_FILE, usecols=["sym"]).sym) if os.path.exists(OLD_LIST_FILE) else set()

    print(f"\nRiptide v5, longs only, {len(ev)} gap events, "
          f"{ev.sym.nunique()} different stocks, after costs")
    print("t above about 2 is unlikely to be luck, above 3 is much safer\n")
    print("from        hold   trades   win   per trade  hedged   t hedged")
    for entry_name, entry_col in (("close", "entry"), ("next open", "next_open")):
        for h in HOLDS:
            e = ev.dropna(subset=[entry_col, f"exit_{h}"])
            raw = e[f"exit_{h}"] / e[entry_col] - 1
            m = midx.reindex(e.day).values
            m_end = midx.shift(-h).reindex(e.day).values
            hedged = raw - (m_end / m - 1) - COST_PER_TRADE
            pnl = raw - COST_PER_TRADE
            ok = np.isfinite(hedged)
            ev.loc[e.index[ok], f"h_{entry_col}_{h}"] = hedged[ok]
            print(f"{entry_name:<11} {h:>4} {ok.sum():>8} {(pnl[ok] > 0).mean():6.1%} "
                  f"{pnl[ok].mean():+9.2%} {hedged[ok].mean():+8.2%} "
                  f"{tscore(hedged[ok], e.day[ok]):+8.1f}")

    key = "h_entry_10"
    e = ev.dropna(subset=[key])
    print("\n10 day hold from the close, hedged, by group")
    groups = {
        "in v4's 211 stocks": e.sym.isin(old),
        "all the others": ~e.sym.isin(old),
        "thin, under $20M a day": e.dollar_vol < 2e7,
        "medium, $20M to $100M": (e.dollar_vol >= 2e7) & (e.dollar_vol < 1e8),
        "heavy, over $100M": e.dollar_vol >= 1e8,
        "gap 4 to 8 percent": e.gap < 0.08,
        "gap over 8 percent": e.gap >= 0.08,
    }
    for name, g in groups.items():
        x = e[g]
        if len(x) >= 30:
            print(f"  {name:<24} {len(x):>6} trades  {x[key].mean():+6.2%}  t {tscore(x[key], x.day):+5.1f}")

    print("\n10 day hold from the close, hedged, by year")
    for y, x in e.groupby(e.day.dt.year):
        print(f"  {y}  {len(x):>6} trades  {x[key].mean():+6.2%}")


left, total = run()
report()
print(f"\n{left} of {total} slices left. " + ("Run the cell again to continue." if left else
      "All done, send this to Claude."))
