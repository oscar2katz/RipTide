"""
RIPTIDE LIVE, paper trading the gap and hold drift (part of Ocean Outlays)

Two parts, same cell.
    At home, any evening (good wifi), run it once. The market is closed,
    so it does the heavy prep, finding which stocks are liquid enough and
    their normal volume, and saves it. Prep lasts four days.
    At 2:35 to 2:50pm Chicago on a trading day, run it again. With the
    prep saved, this part is only a handful of small requests, so weak
    school wifi can handle it.

What the 2:40 run does
    1. Sells anything Riptide has held for HOLD_DAYS trading days
    2. Finds stocks that gapped up 4 percent or more today, are still up
       4 percent or more, on heavy volume
    3. Prints the calls and buys them in your Alpaca PAPER account
    4. Keeps a record of every call so we can judge it on real, unseen days

PAPER ONLY. The address below is the paper account, so no real money
moves. Leave it that way until the forward record earns real money.

Paste into a new cell, add your keys, run it daily. Set PLACE_ORDERS to
False if you only want the calls without buying anything.
"""

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd

ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
TRADE_URL = "https://paper-api.alpaca.markets"     # paper account, do not change for now
DATA_URL = "https://data.alpaca.markets"
PLACE_ORDERS = True
HOLD_DAYS = 10
POSITION_PCT = 0.03        # each trade uses 3 percent of the paper account
MAX_POSITIONS = 30         # more small trades means a faster, more trustworthy record
MAX_NEW_PER_DAY = 3
MIN_DOLLAR_VOL = 5e6       # skip stocks that trade under 5 million dollars a day
GAP_MIN = 0.04
VOLUME_MULT = 1.7          # a bit lower than 2 because the day isn't over at 2:40
MIN_PRICE = 5.0
EXPECTED_10D = 0.019       # past average 10 day move for these calls, from v4, update after v5

PREP_FILE = "riptide_prep.csv"
LOG_FILE = "riptide_live_log.csv"


def http(method, url, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method, headers={
        "APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET,
        "Content-Type": "application/json"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            if e.code == 429:
                time.sleep(20)
                continue
            raise RuntimeError(f"Alpaca said {e.code} {e.read().decode()[:200]}")
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt == 3:
                raise
            time.sleep(10 * (attempt + 1))
    raise RuntimeError("Alpaca kept saying slow down, try again in a minute")


def snapshots(syms):
    out = {}
    for i in range(0, len(syms), 200):
        q = {"symbols": ",".join(syms[i:i + 200]), "feed": "iex"}
        out.update(http("GET", f"{DATA_URL}/v2/stocks/snapshots?" + urllib.parse.urlencode(q)))
    return out


def daily_bars(syms, feed, days_back=45):
    start = (datetime.now(timezone.utc) - timedelta(days=days_back)).strftime("%Y-%m-%d")
    out = {}
    for i in range(0, len(syms), 100):
        token = None
        while True:
            q = {"symbols": ",".join(syms[i:i + 100]), "timeframe": "1Day", "start": start,
                 "limit": 10000, "feed": feed}
            if token:
                q["page_token"] = token
            data = http("GET", f"{DATA_URL}/v2/stocks/bars?" + urllib.parse.urlencode(q))
            for s, bars in (data.get("bars") or {}).items():
                out.setdefault(s, []).extend(bars)
            token = data.get("next_page_token")
            if not token:
                break
    return out


def prep(today):
    """Heavy part, best done at home. Liquid stocks and their normal IEX volume."""
    print("prepping, this is the big download, best on good wifi...")
    assets = http("GET", f"{TRADE_URL}/v2/assets?status=active&asset_class=us_equity")
    syms = sorted(a["symbol"] for a in assets if a.get("tradable")
                  and a.get("exchange") in ("NYSE", "NASDAQ", "AMEX")
                  and a["symbol"].isalpha() and len(a["symbol"]) <= 5)
    print(f"  {len(syms)} stocks, checking which trade enough")
    sip = daily_bars(syms, "sip")
    keep = []
    for s, bars in sip.items():
        bars = [b for b in bars if b["t"][:10] < today][-20:]
        if len(bars) >= 10:
            dollar = np.mean([b["c"] * b["v"] for b in bars])
            if bars[-1]["c"] >= MIN_PRICE and dollar >= MIN_DOLLAR_VOL:
                keep.append(s)
    print(f"  {len(keep)} liquid stocks, getting their normal volume")
    iex = daily_bars(keep, "iex")
    rows = []
    for s, bars in iex.items():
        vols = [b["v"] for b in bars if b["t"][:10] < today][-20:]
        if len(vols) >= 10 and np.mean(vols) > 0:
            rows.append((s, np.mean(vols)))
    df = pd.DataFrame(rows, columns=["sym", "avg_vol"])
    df["prepped"] = today
    df.to_csv(PREP_FILE, index=False)
    print(f"  prep saved, {len(df)} stocks")
    return df


def load_prep(today):
    if os.path.exists(PREP_FILE):
        df = pd.read_csv(PREP_FILE)
        age = (pd.Timestamp(today) - pd.Timestamp(str(df.prepped.iloc[0]))).days
        if len(df) and age <= 4:
            return df
    return None


def trading_days_between(a, b):
    return int(np.busday_count(pd.Timestamp(a).date(), pd.Timestamp(b).date()))


def load_log():
    if os.path.exists(LOG_FILE):
        return pd.read_csv(LOG_FILE, dtype={"exit_day": str})
    return pd.DataFrame(columns=["day", "sym", "entry", "qty", "exit_day", "exit"])


def sell_expired(log, today, prices):
    held = {p["symbol"]: p for p in http("GET", f"{TRADE_URL}/v2/positions")}
    for i, row in log[log.exit_day.isna() | (log.exit_day == "")].iterrows():
        if trading_days_between(row.day, today) < HOLD_DAYS:
            continue
        px = prices.get(row.sym)
        if PLACE_ORDERS and row.sym in held:
            http("POST", f"{TRADE_URL}/v2/orders", {
                "symbol": row.sym, "qty": str(int(row.qty)), "side": "sell",
                "type": "market", "time_in_force": "day"})
        log.at[i, "exit_day"] = today
        log.at[i, "exit"] = px
        if px:
            print(f"SOLD  {row.sym:<5} after {HOLD_DAYS} days   {px / row.entry - 1:+.1%}")
    return log


def main():
    now = datetime.now(timezone.utc)
    clock = http("GET", f"{TRADE_URL}/v2/clock")
    today = clock["timestamp"][:10]
    if not clock.get("is_open"):
        prep(today)
        print("\nMarket is closed, so that was the prep. Run again between 2:35 and 2:50pm Chicago.")
        return
    p = load_prep(today)
    if p is None:
        print("No fresh prep found, doing it now. This is slow on weak wifi, next time prep at home.")
        p = prep(today)
    vols = dict(zip(p.sym, p.avg_vol))
    syms = list(p.sym)
    log = load_log()
    print(f"RIPTIDE LIVE {today}, checking {len(syms)} stocks...")
    snap = snapshots(syms)
    prices = {s: v["latestTrade"]["p"] for s, v in snap.items() if v and v.get("latestTrade")}

    log = sell_expired(log, today, prices)

    calls = []
    for s, v in snap.items():
        try:
            prev_c = v["prevDailyBar"]["c"]
            day_bar = v["dailyBar"]
            if day_bar["t"][:10] != today:
                continue
            gap = day_bar["o"] / prev_c - 1
            move = prices[s] / prev_c - 1
            vol_ratio = day_bar["v"] / vols[s]
        except (KeyError, TypeError, ZeroDivisionError):
            continue
        if prev_c >= MIN_PRICE and gap >= GAP_MIN and move >= GAP_MIN and vol_ratio >= VOLUME_MULT:
            calls.append((vol_ratio, s, gap, move, prices[s]))
    calls.sort(reverse=True)

    open_now = log[log.exit_day.isna() | (log.exit_day == "")]
    slots = max(0, MAX_POSITIONS - len(open_now))
    already = set(open_now.sym)
    equity = float(http("GET", f"{TRADE_URL}/v2/account")["equity"])

    if not calls:
        print("\nNo calls today. Nothing gapped up and held on heavy volume.")
    else:
        print("\nToday's calls, hold about 10 trading days")
    new_rows = []
    for vol_ratio, s, gap, move, px in calls:
        target = px * (1 + EXPECTED_10D)
        status = ""
        if s in already:
            status = "already holding"
        elif len(new_rows) >= min(slots, MAX_NEW_PER_DAY):
            status = "no room, skipped"
        print(f"{s:<5} UP  +{EXPECTED_10D:.1%} in 10 days, to {target:.2f}   "
              f"gapped {gap:+.1%}, now {move:+.1%}, volume {vol_ratio:.1f}x  {status}")
        if status:
            continue
        qty = int(equity * POSITION_PCT // px)
        if qty < 1:
            continue
        if PLACE_ORDERS:
            http("POST", f"{TRADE_URL}/v2/orders", {
                "symbol": s, "qty": str(qty), "side": "buy",
                "type": "market", "time_in_force": "day"})
        new_rows.append({"day": today, "sym": s, "entry": px, "qty": qty, "exit_day": "", "exit": np.nan})
    if new_rows:
        log = pd.concat([log, pd.DataFrame(new_rows)], ignore_index=True)
        print(f"\n{'Bought' if PLACE_ORDERS else 'Would buy'} {len(new_rows)} in the paper account")
    log.to_csv(LOG_FILE, index=False)

    closed = log[log.exit.notna()]
    if len(closed):
        r = closed.exit / closed.entry - 1
        print(f"\nForward record, {len(closed)} closed calls, win {(r > 0).mean():.0%}, "
              f"average {r.mean():+.2%} per call")
    print(f"{len(log) - len(closed)} calls still open")


main()
