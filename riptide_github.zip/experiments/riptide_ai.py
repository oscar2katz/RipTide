"""
RIPTIDE AI, backtest (part of Ocean Outlays)

Reads every earnings press release US companies filed with the SEC since
CLEAN_START, scores how good the news really is, then checks whether the
stock kept drifting the way the reading said over the following days.

Only news from after the AI's training is used, so the AI can't already
"know" what happened next. That keeps the test honest.

TWO MODES
    MODE = "dryrun"   Free. Downloads everything, scores each release with a
                      simple free word counting method, shows those results,
                      and tells you exactly what the AI step would cost.
    MODE = "ai"       Has Claude Haiku read each release. Never spends more
                      than MAX_SPEND, and never pays for the same release twice.

HOW TO RUN
    New notebook, one cell. Fill in the settings, run it over and over.
    Each run works for RUN_MINUTES, saves progress, and stops. Do the
    downloading at home on good wifi. When it says the dry run is done,
    send Claude the output, then decide whether to switch MODE to "ai".
"""

import gzip
import html
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd

# settings
ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
ANTHROPIC_KEY = "PASTE_CLAUDE_API_KEY"         # only needed for MODE = "ai"
SEC_USER_AGENT = "Your Name your@email.com"    # the SEC requires a name and email
MODE = "dryrun"
MAX_SPEND = 3.00           # dollars, the AI step stops here no matter what
RUN_MINUTES = 10
CLEAN_START = "2026-07-01" # after the AI's training, so it can't know the future
MIN_PRICE = 5.0
MIN_DOLLAR_VOL = 1e7       # companies trading at least 10 million dollars a day
MAX_CHARS = 12000          # how much of each release the AI reads, the top holds the key news
HOLDS = [1, 3, 5, 10, 20]
COST_PER_TRADE = 0.0010

MODEL = "claude-haiku-5-5"
PRICE_IN = 0.10 / 1e6      # dollars per input token
PRICE_OUT = 0.50 / 1e6     # dollars per output token

UNIVERSE_FILE = "rai_universe.csv"
PRICES_FILE = "rai_prices.csv"
SUBS_DONE = "rai_subs_done.txt"
EVENTS_FILE = "rai_events.csv"
TEXT_DIR = "rai_texts"
TEXT_DONE = "rai_texts_done.txt"
SCORES_FILE = "rai_scores.csv"

DEADLINE = time.time() + RUN_MINUTES * 60
_last_sec = [0.0]


class OutOfTime(Exception):
    pass


def check_time():
    if time.time() > DEADLINE:
        raise OutOfTime()


def http(url, headers=None, body=None, sec=False, raw=False):
    headers = dict(headers or {})
    if sec:
        headers.update({"User-Agent": SEC_USER_AGENT, "Accept-Encoding": "gzip"})
        wait = 0.15 - (time.time() - _last_sec[0])   # stay under the SEC's 10 per second
        if wait > 0:
            time.sleep(wait)
        _last_sec[0] = time.time()
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers,
                                 method="POST" if data else "GET")
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                content = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    content = gzip.decompress(content)
                return content if raw else json.loads(content)
        except urllib.error.HTTPError as e:
            if e.code in (429, 529, 500, 502, 503):
                time.sleep(10 * (attempt + 1))
                continue
            if e.code == 404:
                return None
            raise RuntimeError(f"{url[:60]} said {e.code} {e.read()[:200]}")
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt == 4:
                raise
            time.sleep(10 * (attempt + 1))
    raise RuntimeError("the server kept saying slow down, run again in a few minutes")


def alpaca(url):
    return http(url, {"APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET})


def lines(path):
    return set(open(path).read().split()) if os.path.exists(path) else set()


# stage 1, which companies and their prices
def stage_universe():
    if os.path.exists(UNIVERSE_FILE) and os.path.exists(PRICES_FILE):
        return pd.read_csv(UNIVERSE_FILE)
    print("stage 1 of 4, finding liquid companies and their prices")
    assets = alpaca("https://paper-api.alpaca.markets/v2/assets?status=active&asset_class=us_equity")
    syms = sorted(a["symbol"] for a in assets if a.get("exchange") in ("NYSE", "NASDAQ", "AMEX")
                  and a["symbol"].isalpha() and len(a["symbol"]) <= 5)
    start = (pd.Timestamp(CLEAN_START) - pd.Timedelta(days=45)).strftime("%Y-%m-%d")
    rows = []
    for i in range(0, len(syms), 100):
        token = None
        while True:
            q = {"symbols": ",".join(syms[i:i + 100]), "timeframe": "1Day", "start": start,
                 "limit": 10000, "adjustment": "all", "feed": "sip"}
            if token:
                q["page_token"] = token
            data = alpaca("https://data.alpaca.markets/v2/stocks/bars?" + urllib.parse.urlencode(q))
            for s, bars in (data.get("bars") or {}).items():
                rows += [(s, b["t"][:10], b["c"], b["v"]) for b in bars]
            token = data.get("next_page_token")
            if not token:
                break
        if (i // 100) % 10 == 9:
            print(f"  prices for {min(i + 100, len(syms))} of {len(syms)}")
    px = pd.DataFrame(rows, columns=["sym", "day", "c", "v"])
    dv = (px.c * px.v).groupby(px.sym).median()
    last = px.groupby("sym").c.last()
    keep = set(dv[dv >= MIN_DOLLAR_VOL].index) & set(last[last >= MIN_PRICE].index)
    if "SPY" not in keep and "SPY" in set(px.sym):
        keep.add("SPY")
    tickers = http("https://www.sec.gov/files/company_tickers.json", sec=True)
    cik = {v["ticker"]: int(v["cik_str"]) for v in tickers.values()}
    uni = pd.DataFrame([(s, cik[s]) for s in sorted(keep) if s in cik], columns=["sym", "cik"])
    px[px.sym.isin(keep)][["sym", "day", "c"]].to_csv(PRICES_FILE, index=False)
    uni.to_csv(UNIVERSE_FILE, index=False)
    print(f"  {len(uni)} companies kept")
    return uni


# stage 2, find each company's earnings filings
def stage_filings(uni):
    done = lines(SUBS_DONE)
    todo = uni[~uni.sym.isin(done)]
    if todo.empty:
        return True
    print(f"stage 2 of 4, finding earnings filings, {len(todo)} companies left")
    for n, (sym, cik) in enumerate(zip(todo.sym, todo.cik), 1):
        check_time()
        sub = http(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", sec=True)
        rec = (sub or {}).get("filings", {}).get("recent", {})
        rows = []
        for i, form in enumerate(rec.get("form", [])):
            if form != "8-K" or "2.02" not in (rec["items"][i] or ""):
                continue
            if rec["filingDate"][i] < CLEAN_START:
                continue
            rows.append({"sym": sym, "cik": cik, "acc": rec["accessionNumber"][i],
                         "filed": rec["acceptanceDateTime"][i][:19]})
        if rows:
            pd.DataFrame(rows).to_csv(EVENTS_FILE, mode="a",
                                      header=not os.path.exists(EVENTS_FILE), index=False)
        with open(SUBS_DONE, "a") as f:
            f.write(sym + "\n")
        if n % 100 == 0:
            print(f"  {n} done this run")
    return True


def find_press_release(cik, acc):
    folder = f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc.replace('-', '')}"
    page = http(f"{folder}/{acc}-index.htm", sec=True, raw=True)
    if not page:
        return None
    page = page.decode("utf-8", "ignore")
    best = None
    for row in re.findall(r"<tr[^>]*>(.*?)</tr>", page, re.S | re.I):
        link = re.search(r'href="([^"]+\.(?:htm|html|txt))"', row, re.I)
        if not link:
            continue
        cells = [re.sub(r"<[^>]+>", "", c).strip() for c in re.findall(r"<td[^>]*>(.*?)</td>", row, re.S | re.I)]
        kind = next((c.upper() for c in cells if c.upper().startswith("EX-99")), "")
        if kind.startswith("EX-99.1") or (kind and best is None):
            best = link.group(1)
            if kind.startswith("EX-99.1"):
                break
    if not best:
        return None
    best = best.replace("/ix?doc=", "")
    url = best if best.startswith("http") else "https://www.sec.gov" + best
    doc = http(url, sec=True, raw=True)
    return doc.decode("utf-8", "ignore") if doc else None


def clean_text(raw):
    raw = re.sub(r"(?is)<(script|style).*?</\1>", " ", raw)
    raw = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</tr>", "\n", raw)
    text = html.unescape(re.sub(r"<[^>]+>", " ", raw))
    text = re.sub(r"[ \t\xa0]+", " ", text)
    return re.sub(r"\n\s*\n+", "\n", text).strip()


# stage 3, download the press releases
def stage_texts():
    if not os.path.exists(EVENTS_FILE):
        print("no earnings filings found, check SEC_USER_AGENT and CLEAN_START")
        return False
    os.makedirs(TEXT_DIR, exist_ok=True)
    ev = pd.read_csv(EVENTS_FILE).drop_duplicates("acc")
    done = lines(TEXT_DONE)
    todo = ev[~ev.acc.isin(done)]
    if todo.empty:
        return True
    print(f"stage 3 of 4, downloading press releases, {len(todo)} left")
    for n, (cik, acc) in enumerate(zip(todo.cik, todo.acc), 1):
        check_time()
        raw = find_press_release(cik, acc)
        if raw:
            with open(os.path.join(TEXT_DIR, acc + ".txt"), "w") as f:
                f.write(clean_text(raw)[:MAX_CHARS])
        with open(TEXT_DONE, "a") as f:
            f.write(acc + "\n")
        if n % 100 == 0:
            print(f"  {n} done this run")
    return True


def read_text(acc):
    path = os.path.join(TEXT_DIR, acc + ".txt")
    return open(path).read() if os.path.exists(path) else None


# free scoring, simple word counting as a baseline to beat
POS = set("""record exceeded exceed beat beats strong stronger growth grew raised raise raises
increase increased improved improvement accelerated momentum outperformed robust upside
expanded expansion higher exceeding surpassed favorable""".split())
NEG = set("""decline declined decrease decreased lowered lower lowers weak weaker weakness miss
missed loss losses impairment headwinds challenging softness slowdown below reduced reduce
restructuring disappointing pressure unfavorable shortfall""".split())


def word_score(text):
    words = re.findall(r"[a-z]+", text.lower())
    if not words:
        return np.nan
    p = sum(w in POS for w in words)
    n = sum(w in NEG for w in words)
    return (p - n) / max(p + n, 1)


# stage 4, AI scoring
PROMPT = """You are a skeptical equity analyst. Read this earnings press release and judge
how good the news really is for the stock compared with what investors most likely
expected. Weigh beats or misses, guidance changes, margins, cash flow, and anything
negative buried in the details. Reply with ONLY this JSON and nothing else.
{"score": integer from -5 (very bad) to 5 (very good), "guidance": "raised" or "lowered" or "maintained" or "none", "confidence": 1 to 3, "why": "under 15 words"}"""


def spent():
    if not os.path.exists(SCORES_FILE):
        return 0.0
    s = pd.read_csv(SCORES_FILE)
    return float((s.in_tok * PRICE_IN + s.out_tok * PRICE_OUT).sum())


def stage_ai(ev):
    have = set(pd.read_csv(SCORES_FILE).acc) if os.path.exists(SCORES_FILE) else set()
    todo = [a for a in ev.acc if a not in have and read_text(a)]
    if not todo:
        return True
    print(f"stage 4 of 4, AI reading, {len(todo)} releases left, spent so far ${spent():.2f}")
    for n, acc in enumerate(todo, 1):
        check_time()
        if spent() >= MAX_SPEND:
            print(f"Hit the ${MAX_SPEND:.2f} limit, stopping. Raise MAX_SPEND only if the results so far look worth it.")
            return False
        body = {"model": MODEL, "max_tokens": 100, "system": PROMPT,
                "messages": [{"role": "user", "content": read_text(acc)}]}
        r = http("https://api.anthropic.com/v1/messages",
                 {"x-api-key": ANTHROPIC_KEY, "anthropic-version": "2023-06-01",
                  "content-type": "application/json"}, body)
        out = "".join(c.get("text", "") for c in r.get("content", []))
        m = re.search(r"\{.*\}", out, re.S)
        try:
            j = json.loads(m.group(0)) if m else {}
        except ValueError:
            j = {}
        row = {"acc": acc, "score": j.get("score"), "guidance": j.get("guidance"),
               "confidence": j.get("confidence"), "why": str(j.get("why", ""))[:120],
               "in_tok": r["usage"]["input_tokens"], "out_tok": r["usage"]["output_tokens"]}
        pd.DataFrame([row]).to_csv(SCORES_FILE, mode="a",
                                   header=not os.path.exists(SCORES_FILE), index=False)
        if n <= 3:   # show the first few so you can sanity check the AI's reading
            sym = ev.loc[ev.acc == acc, "sym"].iloc[0]
            print(f"  sample, {sym} score {row['score']} guidance {row['guidance']}, {row['why']}")
        if n % 50 == 0:
            print(f"  {n} read this run, ${spent():.2f} spent")
    return True


# results
def build_table():
    ev = pd.read_csv(EVENTS_FILE).drop_duplicates("acc")
    px = pd.read_csv(PRICES_FILE, parse_dates=["day"])
    C = px.pivot_table(index="day", columns="sym", values="c").sort_index()
    days = C.index
    spy = C["SPY"] if "SPY" in C else C.mean(axis=1)
    rows = []
    for _, e in ev.iterrows():
        if e.sym not in C:
            continue
        filed = pd.Timestamp(e.filed)                # SEC times are New York time
        d = filed.normalize()
        after_close = filed.hour * 60 + filed.minute >= 16 * 60
        i = days.searchsorted(d, side="right" if after_close else "left")
        if i < 1 or i >= len(days):
            continue
        prev, d0 = C[e.sym].iloc[i - 1], C[e.sym].iloc[i]
        row = {"acc": e.acc, "sym": e.sym, "day0": days[i], "react": d0 / prev - 1}
        for h in HOLDS:
            if i + h < len(days):
                stock = C[e.sym].iloc[i + h] / d0 - 1
                mkt = spy.iloc[i + h] / spy.iloc[i] - 1
                row[f"d{h}"] = stock - mkt
        txt = read_text(e.acc)
        row["words"] = word_score(txt) if txt else np.nan
        rows.append(row)
    t = pd.DataFrame(rows)
    if os.path.exists(SCORES_FILE):
        s = pd.read_csv(SCORES_FILE).drop_duplicates("acc")
        t = t.merge(s[["acc", "score", "guidance", "confidence"]], on="acc", how="left")
    return t


def tscore(x):
    x = x.dropna()
    return x.mean() / x.std() * np.sqrt(len(x)) if len(x) > 2 and x.std() > 0 else np.nan


def show(t, col, label, lo, hi):
    """Bad news, middle, good news buckets, plus the underreaction trade."""
    print(f"\n{label}, drift after the reaction day vs the market, before costs")
    print("group                          count    " + "  ".join(f"{h:>2}d" + " " * 4 for h in HOLDS))
    x = t.dropna(subset=[col])
    groups = {
        "bad news": x[x[col] <= lo],
        "middle": x[(x[col] > lo) & (x[col] < hi)],
        "good news": x[x[col] >= hi],
        "good news, stock fell (UP)": x[(x[col] >= hi) & (x.react <= 0)],
        "bad news, stock rose (DOWN)": x[(x[col] <= lo) & (x.react >= 0)],
    }
    for name, g in groups.items():
        cells = "  ".join(f"{g[f'd{h}'].mean():+7.2%}" if f"d{h}" in g and g[f"d{h}"].notna().sum() >= 5
                          else "    n/a" for h in HOLDS)
        print(f"{name:<30} {len(g):>5}  {cells}")
    up = groups["good news, stock fell (UP)"]
    dn = groups["bad news, stock rose (DOWN)"]
    pnl = pd.concat([up["d10"], -dn["d10"]]).dropna() - COST_PER_TRADE if "d10" in x else pd.Series(dtype=float)
    if len(pnl) >= 5:
        print(f"Riptide calls, 10 day hold after costs   {len(pnl)} trades   "
              f"win {(pnl > 0).mean():.0%}   per trade {pnl.mean():+.2%}   t {tscore(pnl):+.1f}")
    good, bad = groups["good news"], groups["bad news"]
    if "d10" in x:
        spread = good["d10"].mean() - bad["d10"].mean()
        print(f"good minus bad news gap at 10 days   {spread:+.2%}")


def report(est_only):
    t = build_table()
    have_txt = t.acc.map(lambda a: read_text(a) is not None)
    print(f"\nRIPTIDE AI, {len(t)} earnings releases since {CLEAN_START}, {have_txt.sum()} with text")
    print("Note, this is a short window, a few months, so treat t scores as early hints")
    show(t, "words", "FREE word counting score", -0.2, 0.4)
    if est_only:
        have = set(pd.read_csv(SCORES_FILE).acc) if os.path.exists(SCORES_FILE) else set()
        left = t[~t.acc.isin(have) & have_txt]
        tok_left = sum(len(read_text(a)) for a in left.acc) / 3.6 + 200 * len(left)
        cost = tok_left * PRICE_IN + len(left) * 60 * PRICE_OUT
        print(f"\nAI step estimate, {len(left)} releases, about {tok_left / 1e6:.1f} million tokens, "
              f"about ${cost:.2f}. MAX_SPEND is ${MAX_SPEND:.2f}.")
    if "score" in t and t.score.notna().sum() >= 20:
        show(t, "score", f"AI score, {t.score.notna().sum()} read", -2, 2)
        print(f"\nAI spending so far ${spent():.2f}")


def main():
    if "your@email" in SEC_USER_AGENT:
        print("Put your name and email in SEC_USER_AGENT first, the SEC blocks requests without it.")
        return
    try:
        uni = stage_universe()
        stage_filings(uni)
        if not stage_texts():
            return
        ev = pd.read_csv(EVENTS_FILE).drop_duplicates("acc")
        if MODE == "ai":
            if "PASTE" in ANTHROPIC_KEY:
                print("Add your Claude API key to use MODE ai.")
                return
            stage_ai(ev)
        report(est_only=(MODE != "ai"))
        print("\nAll caught up. Send this output to Claude.")
    except OutOfTime:
        print(f"\n{RUN_MINUTES} minutes used, progress saved. Run the cell again to continue.")


main()
