"""
RIPTIDE v3, stocks in play (part of Ocean Outlays)

Idea from a 2023 study on opening range breakouts. Each morning, find
the stocks gapping hard at the open on unusual volume. If the first
five minute candle is green, buy if price breaks above its high. If
red, short if price breaks below its low. Stop out at a small fraction
of the stock's normal daily range, otherwise hold to the close.

How to run on the iPad
    1. Paste into one Carnets cell, fill in your Alpaca PAPER keys
    2. Run the cell. It does about 250 trading days per run and saves
       its progress, so just run it again until it says it is done
    3. Every run prints the results so far. Send the final one to Claude

Only needs pandas and numpy.
"""

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd

# settings
ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
START = "2020-01-01"
DAYS_PER_RUN = 250
GAP_MIN = 0.03         # stock must open at least 3 percent away from yesterday's close
MIN_PRICE = 5.0
MIN_ATR = 0.50         # skip stocks that barely move
MAX_CANDIDATES = 40    # biggest gappers checked per day
TOP_N = 5              # trades per day, the most unusual volume wins
RVOL_MIN = 0.10        # first 5 minutes must be at least 10 percent of a normal day's volume
STOPS = [0.10, 0.25, 0.50, 1.00, None]   # stop distances to test, as a fraction of the
                                          # 14 day average range, None means no stop
COST_PER_TRADE = 0.0008  # 0.08 percent, these stocks have wider spreads than ETFs

UNIVERSE = """
AAPL MSFT NVDA AMZN META GOOGL TSLA AMD AVGO NFLX ADBE CRM ORCL INTC QCOM MU TXN
AMAT LRCX KLAC MRVL ON SMCI ARM PANW CRWD ZS NET DDOG SNOW MDB OKTA TEAM SHOP XYZ
PYPL COIN HOOD SOFI AFRM UPST PLTR RBLX U SNAP PINS UBER LYFT ABNB DASH RIVN LCID
NIO XPEV LI F GM CVNA CHWY ETSY EBAY W ROKU SPOT TTD TWLO ZM DOCU PATH AI IONQ
SOUN MARA RIOT MSTR CLSK BA CAT DE GE HON LMT RTX NOC UPS FDX DAL UAL AAL CCL RCL
NCLH MAR HLT DIS CMCSA WBD NKE LULU SBUX MCD CMG DPZ YUM KO PEP WMT TGT COST HD
LOW BBY DG DLTR KR JPM BAC WFC C GS MS SCHW AXP V MA COF XOM CVX OXY COP SLB HAL
DVN FANG MPC VLO PFE MRK LLY ABBV BMY JNJ AMGN GILD MRNA BNTX REGN VRTX BIIB CVS
UNH HUM CI ELV ISRG DXCM TDOC HIMS NVAX ENPH SEDG FSLR RUN PLUG CHPT QS BABA JD
PDD BIDU TSM ASML DELL HPQ HPE WDC STX ANET CSCO IBM NOW INTU WDAY FTNT GME AMC
PTON BYND DKNG PENN MGM WYNN LVS CROX DECK ONON ELF CELH MNST TOST APP ACHR JOBY
RKLB ASTS OKLO SMR CCJ VST CEG NEE
""".split()

DAILY_FILE = "riptide3_daily.csv"
TRADES_FILE = "riptide3_trades.csv"
DONE_FILE = "riptide3_done_days.txt"


def et_offset(ts_utc):
    """New York offset from UTC, done by hand so no timezone database is needed."""
    y = ts_utc.year
    mar1 = date(y, 3, 1)
    dst_start = mar1 + timedelta(days=(6 - mar1.weekday()) % 7 + 7)
    nov1 = date(y, 11, 1)
    dst_end = nov1 + timedelta(days=(6 - nov1.weekday()) % 7)
    start = datetime(y, dst_start.month, dst_start.day, 7, tzinfo=timezone.utc)
    end = datetime(y, dst_end.month, dst_end.day, 6, tzinfo=timezone.utc)
    return timedelta(hours=-4) if start <= ts_utc < end else timedelta(hours=-5)


def fetch(params):
    """Many symbols at once from Alpaca, follows pages, retries when the connection drops."""
    out, token = {}, None
    while True:
        q = dict(params, limit=10000, adjustment="all", feed="sip")
        if token:
            q["page_token"] = token
        url = "https://data.alpaca.markets/v2/stocks/bars?" + urllib.parse.urlencode(q)
        req = urllib.request.Request(url, headers={
            "APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = json.load(r)
                break
            except urllib.error.HTTPError as e:
                if e.code == 429:            # asked too fast, slow down
                    time.sleep(20)
                    continue
                raise RuntimeError(f"Alpaca said {e.code} {e.read().decode()[:200]}")
            except (urllib.error.URLError, TimeoutError, OSError):
                if attempt == 3:
                    raise
                time.sleep(15 * (attempt + 1))
        else:
            raise RuntimeError("Alpaca kept saying slow down, wait a minute and run again")
        for sym, bars in (data.get("bars") or {}).items():
            out.setdefault(sym, []).extend(bars)
        token = data.get("next_page_token")
        if not token:
            return out


def to_et(t):
    x = datetime.fromisoformat(t.replace("Z", "+00:00"))
    return (x + et_offset(x)).replace(tzinfo=None)


def load_daily():
    """Stage 1. Daily prices for the whole list, used to spot the gappers."""
    if os.path.exists(DAILY_FILE):
        return pd.read_csv(DAILY_FILE, parse_dates=["day"])
    print("stage 1, downloading daily prices (one time only)...")
    rows = []
    start = (pd.Timestamp(START) - pd.Timedelta(days=40)).strftime("%Y-%m-%d")
    for i in range(0, len(UNIVERSE), 100):
        chunk = UNIVERSE[i:i + 100]
        got = fetch({"symbols": ",".join(chunk), "timeframe": "1Day", "start": start})
        for sym, bars in got.items():
            for b in bars:
                rows.append((sym, to_et(b["t"]).date(), b["o"], b["h"], b["l"], b["c"], b["v"]))
        print(f"  {min(i + 100, len(UNIVERSE))} of {len(UNIVERSE)} stocks")
    df = pd.DataFrame(rows, columns=["sym", "day", "o", "h", "l", "c", "v"])
    df["day"] = pd.to_datetime(df["day"])
    df.to_csv(DAILY_FILE, index=False)
    return df


def candidates(daily):
    """Everything here is known at the open."""
    d = daily.sort_values(["sym", "day"]).copy()
    g = d.groupby("sym")
    prev_c = g["c"].shift(1)
    tr = pd.concat([d["h"] - d["l"], (d["h"] - prev_c).abs(), (d["l"] - prev_c).abs()], axis=1).max(axis=1)
    d["atr"] = tr.groupby(d["sym"]).transform(lambda s: s.rolling(14).mean().shift(1))
    d["avg_vol"] = g["v"].transform(lambda s: s.rolling(14).mean().shift(1))
    d["gap"] = d["o"] / prev_c - 1
    d["prev_c"] = prev_c
    ok = ((d["gap"].abs() >= GAP_MIN) & (d["prev_c"] >= MIN_PRICE)
          & (d["atr"] >= MIN_ATR) & (d["day"] >= pd.Timestamp(START)))
    d = d[ok].dropna(subset=["atr", "avg_vol"])
    d["absgap"] = d["gap"].abs()
    return d.sort_values("absgap", ascending=False).groupby("day").head(MAX_CANDIDATES)


def simulate(bars, atr, stop_atr):
    """One stock, one day, five minute bars in time order. Returns the result or None.
    Five minute candles can't show whether the breakout or the stop came first inside
    the same candle, so on the entry candle we only count the stop if it closed past it."""
    first = bars[0]
    if first["c"] == first["o"]:
        return None
    side = 1 if first["c"] > first["o"] else -1
    level = first["h"] if side > 0 else first["l"]
    entry = stop = None
    for b in bars[1:]:
        if entry is None:
            hit = b["h"] >= level if side > 0 else b["l"] <= level
            if not hit:
                continue
            entry = level
            if stop_atr is None:
                continue
            stop = entry - side * stop_atr * atr
            if (side > 0 and b["c"] <= stop) or (side < 0 and b["c"] >= stop):
                return side, entry, stop, "stop"
            continue
        if stop is not None and ((side > 0 and b["l"] <= stop) or (side < 0 and b["h"] >= stop)):
            return side, entry, stop, "stop"
    if entry is None:
        return None
    return side, entry, bars[-1]["c"], "close"


def col(stop_atr):
    return "none" if stop_atr is None else f"{stop_atr:.2f}"


def run_batch(cands):
    done = set(open(DONE_FILE).read().split()) if os.path.exists(DONE_FILE) else set()
    days = sorted(cands["day"].unique())
    todo = [d for d in days if pd.Timestamp(d).strftime("%Y-%m-%d") not in done]
    if not todo:
        return 0
    print(f"stage 2, {len(todo)} days left, doing up to {DAYS_PER_RUN} now")
    for n, day in enumerate(todo[:DAYS_PER_RUN], 1):
        day = pd.Timestamp(day)
        today = cands[cands["day"] == day].set_index("sym")
        noon = datetime(day.year, day.month, day.day, 17, tzinfo=timezone.utc)
        off = et_offset(noon)
        open_utc = datetime(day.year, day.month, day.day, 9, 30) - off
        close_utc = datetime(day.year, day.month, day.day, 16, 0) - off
        got = fetch({"symbols": ",".join(today.index), "timeframe": "5Min",
                     "start": open_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
                     "end": close_utc.strftime("%Y-%m-%dT%H:%M:%SZ")})
        picks = []
        for sym, bars in got.items():
            bars = sorted(bars, key=lambda b: b["t"])
            if not bars or to_et(bars[0]["t"]).strftime("%H:%M") != "09:30":
                continue
            rvol = bars[0]["v"] / today.loc[sym, "avg_vol"]
            if rvol >= RVOL_MIN:
                picks.append((rvol, sym, bars))
        picks.sort(key=lambda x: x[0], reverse=True)
        rows = []
        for rvol, sym, bars in picks[:TOP_N]:
            res = {col(k): simulate(bars, today.loc[sym, "atr"], k) for k in STOPS}
            if all(r is None for r in res.values()):
                continue
            row = {"day": day.strftime("%Y-%m-%d"), "sym": sym,
                   "gap": round(today.loc[sym, "gap"], 4), "rvol": round(rvol, 3)}
            for name, r in res.items():
                row[f"ret_{name}"] = r[0] * (r[2] / r[1] - 1) if r else np.nan
                row[f"how_{name}"] = r[3] if r else ""
            rows.append(row)
        if rows:
            pd.DataFrame(rows).to_csv(TRADES_FILE, mode="a",
                                      header=not os.path.exists(TRADES_FILE), index=False)
        with open(DONE_FILE, "a") as f:
            f.write(day.strftime("%Y-%m-%d") + "\n")
        if n % 25 == 0:
            print(f"  {n} days done this run")
    return len(todo) - min(len(todo), DAYS_PER_RUN)


def report():
    if not os.path.exists(TRADES_FILE):
        print("no trades yet")
        return
    t = pd.read_csv(TRADES_FILE, parse_dates=["day"]).drop_duplicates(["day", "sym"])
    print(f"\nRiptide v3 results so far, {t.day.min():%b %Y} to {t.day.max():%b %Y}, after costs")
    print("t above about 2 is unlikely to be luck\n")
    print("stop     trades   win    per trade  before costs   stopped     t")
    years = {}
    for k in STOPS:
        name = col(k)
        r = t[f"ret_{name}"].dropna()
        pnl = r - COST_PER_TRADE
        tstat = pnl.mean() / pnl.std() * np.sqrt(len(pnl))
        stopped = (t.loc[r.index, f"how_{name}"] == "stop").mean()
        print(f"{name:<6} {len(pnl):>8} {(pnl > 0).mean():6.1%} {pnl.mean():+10.3%} "
              f"{r.mean():+12.3%} {stopped:9.0%} {tstat:+7.1f}")
        years[name] = pnl.groupby(t.loc[r.index, "day"].dt.year).mean()
    print("\nper trade by year, after costs")
    print((pd.DataFrame(years) * 100).round(3).astype(str).add("%").to_string())


if os.path.exists(TRADES_FILE) and "ret_none" not in open(TRADES_FILE).readline():
    os.remove(TRADES_FILE)          # results from the old version, start stage 2 over
    if os.path.exists(DONE_FILE):
        os.remove(DONE_FILE)
    print("old results cleared, the daily prices are kept")

daily = load_daily()
left = run_batch(candidates(daily))
report()
print(f"\n{left} days left. " + ("Run the cell again to continue." if left else
      "All done, send this to Claude."))
