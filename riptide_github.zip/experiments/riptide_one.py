"""
RIPTIDE ONE, deep test of a single stock (part of Ocean Outlays)

Is this stock actually predictable? Tests the common ways people try to
trade one name, on years of its own history, against simply holding it.
Free, a few small downloads from Alpaca and the SEC.

New cell anywhere. Add keys and your name and email, run once.
Change SYMBOL to test any other stock.
"""

import gzip
import json
import time
import urllib.error
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
SEC_USER_AGENT = "Your Name your@email.com"
SYMBOL = "MELI"
START = "2016-01-01"
COST_PER_TRADE = 0.0010


def get(url, headers):
    req = urllib.request.Request(url, headers=headers)
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                b = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    b = gzip.decompress(b)
                return json.loads(b)
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt == 4:
                raise
            time.sleep(10 * (attempt + 1))


def prices(sym):
    rows, token = [], None
    while True:
        q = {"timeframe": "1Day", "start": START, "limit": 10000, "adjustment": "all", "feed": "sip"}
        if token:
            q["page_token"] = token
        d = get(f"https://data.alpaca.markets/v2/stocks/{sym}/bars?" + urllib.parse.urlencode(q),
                {"APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET})
        rows += [(b["t"][:10], b["c"]) for b in d.get("bars") or []]
        token = d.get("next_page_token")
        if not token:
            break
    s = pd.DataFrame(rows, columns=["day", "c"]).drop_duplicates("day")
    return s.set_index(pd.to_datetime(s.day))["c"]


def earnings_times(sym):
    h = {"User-Agent": SEC_USER_AGENT, "Accept-Encoding": "gzip"}
    tick = get("https://www.sec.gov/files/company_tickers.json", h)
    cik = next(int(v["cik_str"]) for v in tick.values() if v["ticker"] == sym)
    sub = get(f"https://data.sec.gov/submissions/CIK{cik:010d}.json", h)["filings"]
    pages = [sub["recent"]] + [get(f"https://data.sec.gov/submissions/{f['name']}", h)
                               for f in sub.get("files", [])]   # older filings live here
    out = set()
    for rec in pages:
        for i, f in enumerate(rec["form"]):
            if f == "8-K" and "2.02" in (rec["items"][i] or ""):
                out.add(pd.Timestamp(rec["acceptanceDateTime"][i][:19]))
    return sorted(out)


def tscore(x):
    x = pd.Series(x).dropna()
    return x.mean() / x.std() * np.sqrt(len(x)) if len(x) > 2 and x.std() > 0 else np.nan


def line(name, pnl):
    pnl = pd.Series(pnl).dropna()
    if len(pnl) < 5:
        print(f"  {name:<34} too few trades ({len(pnl)})")
        return
    print(f"  {name:<34} {len(pnl):>5} trades  win {(pnl > 0).mean():4.0%}  "
          f"per trade {pnl.mean():+6.2%}  t {tscore(pnl):+5.1f}")


if "your@email" in SEC_USER_AGENT:
    print("Put your name and email in SEC_USER_AGENT first.")
else:
    c = prices(SYMBOL)
    spy = prices("SPY").reindex(c.index).ffill()
    r = c.pct_change()
    ex = r - spy.pct_change()                       # the stock's own move, market removed
    vol = r.rolling(60).std().shift(1)
    years = (c.index[-1] - c.index[0]).days / 365.25

    print(f"RIPTIDE ONE, {SYMBOL}, {c.index[0]:%b %Y} to {c.index[-1]:%b %Y}")
    print(f"buy and hold {(c.iloc[-1] / c.iloc[0]) ** (1 / years) - 1:+.1%} a year, "
          f"worst drop {(c / c.cummax() - 1).min():.0%}, typical day moves {r.std():.1%}")
    print("t above about 2 is unlikely to be luck. Market moves removed unless noted.\n")

    print("1. Does yesterday predict today?")
    nxt = ex.shift(-1)
    line("after an up day, bet up", (nxt[r > 0] - COST_PER_TRADE))
    line("after a down day, bet up", (nxt[r < 0] - COST_PER_TRADE))
    big_dn = r < -2 * vol
    big_up = r > 2 * vol
    fwd5 = (c.shift(-5) / c - 1) - (spy.shift(-5) / spy - 1)
    line("after a big drop, buy 5 days", fwd5[big_dn] - COST_PER_TRADE)
    line("after a big jump, buy 5 days", fwd5[big_up] - COST_PER_TRADE)
    line("after a big jump, short 5 days", -fwd5[big_up] - COST_PER_TRADE)

    print("\n2. Trend following, hold only above the 50 day average (market included)")
    above = (c > c.rolling(50).mean()).shift(1, fill_value=False)
    trend = r.where(above, 0.0) - above.astype(int).diff().abs().fillna(0) * COST_PER_TRADE
    hold_cum = (1 + r.fillna(0)).cumprod()
    trend_cum = (1 + trend.fillna(0)).cumprod()
    print(f"  trend rule  {trend_cum.iloc[-1] ** (1 / years) - 1:+.1%} a year, "
          f"worst drop {(trend_cum / trend_cum.cummax() - 1).min():.0%}, "
          f"in the stock {above.mean():.0%} of days")
    print(f"  just hold   {hold_cum.iloc[-1] ** (1 / years) - 1:+.1%} a year, "
          f"worst drop {(hold_cum / hold_cum.cummax() - 1).min():.0%}")

    print("\n3. Earnings")
    try:
        times = earnings_times(SYMBOL)
    except Exception as e:
        times = []
        print(f"  could not get earnings dates ({e})")
    days = c.index
    rows = []
    for t in times:
        after = t.hour * 60 + t.minute >= 16 * 60    # SEC times are New York time
        i = days.searchsorted(t.normalize(), side="right" if after else "left")
        if i < 11 or i + 10 >= len(days):
            continue
        run_up = (c.iloc[i - 1] / c.iloc[i - 11] - 1) - (spy.iloc[i - 1] / spy.iloc[i - 11] - 1)
        react = ex.iloc[i]
        drift = (c.iloc[i + 10] / c.iloc[i] - 1) - (spy.iloc[i + 10] / spy.iloc[i] - 1)
        rows.append((days[i], run_up, react, drift))
    e = pd.DataFrame(rows, columns=["day", "run_up", "react", "drift"])
    if len(e) >= 5:
        print(f"  {len(e)} earnings reports found, typical reaction size {e.react.abs().mean():.1%}")
        print(f"  reaction went up {(e.react > 0).mean():.0%} of the time, "
              f"average {e.react.mean():+.1%}, t {tscore(e.react):+.1f}")
        line("buy 10 days before earnings", e.run_up - COST_PER_TRADE)
        line("after up reaction, hold 10 days", e.drift[e.react > 0] - COST_PER_TRADE)
        line("after down reaction, hold 10 days", e.drift[e.react < 0] - COST_PER_TRADE)
        print("\n  last 8 reports")
        for _, x in e.tail(8).iterrows():
            print(f"    {x.day:%Y-%m-%d}  reaction {x.react:+6.1%}   next 10 days {x.drift:+6.1%}")
    print("\nSend this to Claude.")
