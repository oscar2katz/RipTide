"""
RIPTIDE v3 CHECK, one minute candles

The tight stop looked great, but five minute candles hide the order of
events inside them. When a candle breaks out AND dips to the stop, v3
gave the trade the benefit of the doubt. This rechecks every trade v3
picked using one minute candles, so far fewer moments are ambiguous,
and when one still is, it assumes the worst. It also charges extra
slippage when a stop is hit, since stops in fast stocks fill badly.

How to run
    Put this in a NEW cell in the same Carnets notebook as v3, so it
    can find riptide3_trades.csv. Add your keys, run it repeatedly
    until it says all done, then send the final table to Claude.
"""

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd

ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
DAYS_PER_RUN = 250
STOPS = [0.10, 0.25, 0.50, None]
COST_PER_TRADE = 0.0008    # spread and commissions, every trade
STOP_SLIP = 0.0005         # extra 0.05 percent when a stop fills in a fast move

PICKS_FILE = "riptide3_trades.csv"        # written by v3
DAILY_FILE = "riptide3_daily.csv"         # written by v3
OUT_FILE = "riptide3_check_trades.csv"
DONE_FILE = "riptide3_check_done.txt"


def et_offset(ts_utc):
    y = ts_utc.year
    mar1 = date(y, 3, 1)
    dst_start = mar1 + timedelta(days=(6 - mar1.weekday()) % 7 + 7)
    nov1 = date(y, 11, 1)
    dst_end = nov1 + timedelta(days=(6 - nov1.weekday()) % 7)
    start = datetime(y, dst_start.month, dst_start.day, 7, tzinfo=timezone.utc)
    end = datetime(y, dst_end.month, dst_end.day, 6, tzinfo=timezone.utc)
    return timedelta(hours=-4) if start <= ts_utc < end else timedelta(hours=-5)


def fetch(params):
    out, token = {}, None
    while True:
        q = dict(params, limit=10000, adjustment="all", feed="sip")
        if token:
            q["page_token"] = token
        url = "https://data.alpaca.markets/v2/stocks/bars?" + urllib.parse.urlencode(q)
        req = urllib.request.Request(url, headers={
            "APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = json.load(r)
                break
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    time.sleep(20)
                    continue
                raise RuntimeError(f"Alpaca said {e.code} {e.read().decode()[:200]}")
            except (urllib.error.URLError, TimeoutError, OSError):
                if attempt == 3:
                    raise
                time.sleep(15 * (attempt + 1))
        else:
            raise RuntimeError("Alpaca kept saying slow down, wait a minute and run again")
        for sym, bars in (data.get("bars") or {}).items():
            out.setdefault(sym, []).extend(bars)
        token = data.get("next_page_token")
        if not token:
            return out


def atr_table():
    d = pd.read_csv(DAILY_FILE, parse_dates=["day"]).sort_values(["sym", "day"])
    prev_c = d.groupby("sym")["c"].shift(1)
    tr = pd.concat([d["h"] - d["l"], (d["h"] - prev_c).abs(), (d["l"] - prev_c).abs()], axis=1).max(axis=1)
    d["atr"] = tr.groupby(d["sym"]).transform(lambda s: s.rolling(14).mean().shift(1))
    return d.set_index(["day", "sym"])["atr"]


def simulate(bars, atr, stop_atr):
    """bars are one minute candles from 9:30. The opening range is the first five."""
    rng = bars[:5]
    o, c = rng[0]["o"], rng[-1]["c"]
    if c == o:
        return None
    side = 1 if c > o else -1
    level = max(b["h"] for b in rng) if side > 0 else min(b["l"] for b in rng)
    entry = stop = None
    for b in bars[5:]:
        if entry is None:
            hit = b["h"] >= level if side > 0 else b["l"] <= level
            if not hit:
                continue
            entry = level
            if stop_atr is not None:
                stop = entry - side * stop_atr * atr
        # worst case, the stop counts even inside the entry minute
        if stop is not None and ((side > 0 and b["l"] <= stop) or (side < 0 and b["h"] >= stop)):
            return side * (stop / entry - 1) - STOP_SLIP, "stop"
    if entry is None:
        return None
    return side * (bars[-1]["c"] / entry - 1), "close"


def col(k):
    return "none" if k is None else f"{k:.2f}"


def run_batch():
    picks = pd.read_csv(PICKS_FILE, parse_dates=["day"]).drop_duplicates(["day", "sym"])
    atr = atr_table()
    done = set(open(DONE_FILE).read().split()) if os.path.exists(DONE_FILE) else set()
    days = sorted(d for d in picks["day"].unique() if pd.Timestamp(d).strftime("%Y-%m-%d") not in done)
    if not days:
        return 0
    print(f"{len(days)} days left, doing up to {DAYS_PER_RUN} now")
    for n, day in enumerate(days[:DAYS_PER_RUN], 1):
        day = pd.Timestamp(day)
        syms = list(picks.loc[picks["day"] == day, "sym"])
        off = et_offset(datetime(day.year, day.month, day.day, 17, tzinfo=timezone.utc))
        start = datetime(day.year, day.month, day.day, 9, 30) - off
        end = datetime(day.year, day.month, day.day, 16, 0) - off
        got = fetch({"symbols": ",".join(syms), "timeframe": "1Min",
                     "start": start.strftime("%Y-%m-%dT%H:%M:%SZ"),
                     "end": end.strftime("%Y-%m-%dT%H:%M:%SZ")})
        rows = []
        for sym, bars in got.items():
            bars = sorted(bars, key=lambda b: b["t"])
            first = datetime.fromisoformat(bars[0]["t"].replace("Z", "+00:00")) if bars else None
            if not bars or first.replace(tzinfo=None) != start or len(bars) < 30:
                continue
            a = atr.get((day, sym), np.nan)
            if not np.isfinite(a):
                continue
            row = {"day": day.strftime("%Y-%m-%d"), "sym": sym}
            for k in STOPS:
                r = simulate(bars, a, k)
                row[f"ret_{col(k)}"] = r[0] if r else np.nan
                row[f"how_{col(k)}"] = r[1] if r else ""
            rows.append(row)
        if rows:
            pd.DataFrame(rows).to_csv(OUT_FILE, mode="a",
                                      header=not os.path.exists(OUT_FILE), index=False)
        with open(DONE_FILE, "a") as f:
            f.write(day.strftime("%Y-%m-%d") + "\n")
        if n % 25 == 0:
            print(f"  {n} days done this run")
    return len(days) - min(len(days), DAYS_PER_RUN)


def report():
    if not os.path.exists(OUT_FILE):
        print("no trades yet")
        return
    t = pd.read_csv(OUT_FILE, parse_dates=["day"]).drop_duplicates(["day", "sym"])
    print(f"\nRiptide v3 one minute check, {t.day.min():%b %Y} to {t.day.max():%b %Y}, after all costs")
    print("t above about 2 is unlikely to be luck\n")
    print("stop     trades   win    per trade  stopped     t")
    years = {}
    for k in STOPS:
        name = col(k)
        r = t[f"ret_{name}"].dropna()
        pnl = r - COST_PER_TRADE
        tstat = pnl.mean() / pnl.std() * np.sqrt(len(pnl))
        stopped = (t.loc[r.index, f"how_{name}"] == "stop").mean()
        print(f"{name:<6} {len(pnl):>8} {(pnl > 0).mean():6.1%} {pnl.mean():+10.3%} "
              f"{stopped:8.0%} {tstat:+7.1f}")
        years[name] = pnl.groupby(t.loc[r.index, "day"].dt.year).mean()
    print("\nper trade by year")
    print((pd.DataFrame(years) * 100).round(3).astype(str).add("%").to_string())


if not os.path.exists(PICKS_FILE):
    print("Can't find riptide3_trades.csv, run this in the same notebook folder as v3")
else:
    left = run_batch()
    report()
    print(f"\n{left} days left. " + ("Run the cell again to continue." if left else
          "All done, send this to Claude."))
