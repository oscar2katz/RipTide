"""
RIPTIDE v2, end of day caller (part of Ocean Outlays)

The idea comes from published research on SPY. How the market moved
from yesterday's close through the first half hour of today tends to
predict which way it moves in the last half hour, partly because big
funds rebalance near the close. Riptide makes one call per ETF per day.

When to run live      2:30pm Chicago (3:30pm New York)
What it says          UP, DOWN or SKIP into the 3:00pm Chicago close,
                      the expected move, and how often that kind of
                      call won in the past
How to use in Carnets paste into one cell, fill in your Alpaca PAPER
                      keys, set MODE, run the cell

Only needs pandas and numpy.
"""

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd

# settings
ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
MODE = "backtest"          # "backtest" tests years of history, "today" gives live calls
TICKERS = ["SPY", "QQQ", "IWM", "DIA"]
START = "2016-01-01"
COST_PER_TRADE = 0.0002    # 0.02 percent, realistic for these very liquid ETFs
LOOKBACK_DAYS = 750        # past days used to measure win rate and expected move


def et_offset(ts_utc):
    """New York offset from UTC, done by hand so no timezone database is needed."""
    y = ts_utc.year
    mar1 = date(y, 3, 1)
    dst_start = mar1 + timedelta(days=(6 - mar1.weekday()) % 7 + 7)   # 2nd Sunday March
    nov1 = date(y, 11, 1)
    dst_end = nov1 + timedelta(days=(6 - nov1.weekday()) % 7)          # 1st Sunday Nov
    start = datetime(y, dst_start.month, dst_start.day, 7, tzinfo=timezone.utc)
    end = datetime(y, dst_end.month, dst_end.day, 6, tzinfo=timezone.utc)
    return timedelta(hours=-4) if start <= ts_utc < end else timedelta(hours=-5)


def get_bars(symbol, start, end=None, feed="sip"):
    """30 minute bars from Alpaca, times returned in New York time."""
    rows, token = [], None
    while True:
        q = {"timeframe": "30Min", "start": start, "limit": 10000,
             "adjustment": "all", "feed": feed}
        if end:
            q["end"] = end
        if token:
            q["page_token"] = token
        url = f"https://data.alpaca.markets/v2/stocks/{symbol}/bars?" + urllib.parse.urlencode(q)
        req = urllib.request.Request(url, headers={
            "APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET})
        for attempt in range(4):   # phone connections drop, so retry a few times
            try:
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = json.load(r)
                break
            except urllib.error.HTTPError as e:
                if e.code == 403 and feed == "sip":
                    return get_bars(symbol, start, end, feed="iex")
                raise RuntimeError(f"Alpaca said {e.code} {e.read().decode()[:200]}")
            except (urllib.error.URLError, TimeoutError, OSError):
                if attempt == 3:
                    raise
                time.sleep(15 * (attempt + 1))
        rows += data.get("bars") or []
        token = data.get("next_page_token")
        if not token:
            break
    if not rows:
        return pd.DataFrame(columns=["close"])
    t = [datetime.fromisoformat(b["t"].replace("Z", "+00:00")) for b in rows]
    et = [(x + et_offset(x)).replace(tzinfo=None) for x in t]
    return pd.DataFrame({"close": [b["c"] for b in rows]}, index=pd.DatetimeIndex(et))


def daily_table(bars):
    """One row per day with the half hour returns the strategy uses.
    Bars are labeled by start time, so the 9:30 bar closes at 10:00."""
    b = bars.copy()
    b["day"] = b.index.normalize()
    b["hm"] = b.index.strftime("%H:%M")
    piv = b.pivot_table(index="day", columns="hm", values="close", aggfunc="last")
    piv = piv.dropna(subset=["09:30", "14:30", "15:00", "15:30"])
    d = pd.DataFrame(index=piv.index)
    d["prev_close"] = piv["15:30"].shift(1)
    d["first"] = piv["09:30"] / d["prev_close"] - 1           # yesterday close to 10:00
    d["twelfth"] = piv["15:00"] / piv["14:30"] - 1            # 3:00 to 3:30
    d["entry"] = piv["15:00"]                                  # price at 3:30
    d["last"] = piv["15:30"] / piv["15:00"] - 1                # 3:30 to 4:00, what we predict
    d["vol"] = d["first"].abs().rolling(20).mean().shift(1)    # how jumpy recent mornings were
    return d.dropna()


def signals(d):
    """Three versions of the rule, all using only info known at 3:30."""
    s = pd.DataFrame(index=d.index)
    s["basic"] = np.sign(d["first"])
    strong = d["first"].abs() > d["vol"]
    s["strong_morning"] = np.where(strong, np.sign(d["first"]), 0)
    agree = np.sign(d["first"]) == np.sign(d["twelfth"])
    s["both_agree"] = np.where(agree, np.sign(d["first"]), 0)
    return s


def summarize(name, pnl):
    pnl = pnl.dropna()
    if len(pnl) < 30:
        print(f"{name:<15} too few trades")
        return
    years = (pnl.index[-1] - pnl.index[0]).days / 365.25
    t_stat = pnl.mean() / pnl.std() * np.sqrt(len(pnl))
    print(f"{name:<15} trades {len(pnl):>5}   win {(pnl > 0).mean():5.1%}   "
          f"per trade {pnl.mean():+.3%} (before costs {pnl.mean() + COST_PER_TRADE:+.3%})   per year {pnl.sum() / years:+6.1%}   "
          f"t {t_stat:+.1f}")


def backtest():
    print("Riptide v2 backtest, after costs")
    print("t above about 2 means the result is unlikely to be pure luck")
    for sym in TICKERS:
        print(f"\nloading {sym}...")
        cache = f"riptide_{sym}_30min.csv"   # saved so a rerun skips the download
        try:
            bars = pd.read_csv(cache, index_col=0, parse_dates=True)
        except FileNotFoundError:
            try:
                bars = get_bars(sym, START)
            except Exception as e:
                print(f"{sym} download failed ({e}), run again to retry it")
                continue
            bars.to_csv(cache)
        d = daily_table(bars)
        s = signals(d)
        print(f"{sym}  {d.index[0]:%Y} to {d.index[-1]:%Y}, {len(d)} days")
        for col in s.columns:
            traded = s[col] != 0
            summarize(col, (s[col] * d["last"] - COST_PER_TRADE)[traded])
        traded = s["strong_morning"] != 0
        pnl = (s["strong_morning"] * d["last"] - COST_PER_TRADE)[traded]
        by_year = pnl.groupby(pnl.index.year).agg(
            trades="count", win=lambda x: (x > 0).mean(), total="sum")
        print("strong_morning by year")
        print(by_year.round(3).to_string())
    print("\nSend all of this to Claude to pick the version that goes live.")


def today():
    now = datetime.now(timezone.utc)
    start = (now - timedelta(days=int(LOOKBACK_DAYS * 1.5))).strftime("%Y-%m-%d")
    print(f"RIPTIDE calls for {now + et_offset(now):%a %b %d}, hold to the close\n")
    for sym in TICKERS:
        hist = daily_table(get_bars(sym, start))
        live = get_bars(sym, (now - timedelta(days=6)).strftime("%Y-%m-%d"), feed="iex")
        if live.empty:
            print(f"{sym:<5} SKIP   no data yet today")
            continue
        days = live.index.normalize()
        today_bars = live[days == days[-1]]
        hm = today_bars.index.strftime("%H:%M")
        if "09:30" not in hm or "14:30" not in hm:
            print(f"{sym:<5} SKIP   too early, run at 2:30pm Chicago")
            continue
        hist = hist[hist.index < days[-1]]
        prev_close = hist["entry"].iloc[-1] * (1 + hist["last"].iloc[-1])
        first = today_bars["close"][hm == "09:30"].iloc[-1] / prev_close - 1
        price = today_bars["close"].iloc[-1]
        if abs(first) <= hist["first"].abs().tail(20).mean():
            print(f"{sym:<5} SKIP   morning move too small")
            continue
        side = np.sign(first)
        past = hist.tail(LOOKBACK_DAYS)
        past = past[past["first"].abs() > past["vol"]]
        outcome = np.sign(past["first"]) * past["last"]
        move = side * outcome.mean()
        word = "UP  " if side > 0 else "DOWN"
        print(f"{sym:<5} {word}   {move:+.2%}   to {price * (1 + move):.2f}   "
              f"won {(outcome > 0).mean():.0%} of past calls like this")


if MODE == "backtest":
    backtest()
else:
    today()
