"""
RIPTIDE v5 FADE, can you profit from big gap ups falling back?

v5 showed that stocks gapping up hard tend to drop over the next
weeks, especially gaps over 8 percent. This checks whether SHORTING
them would really pay, using the events v5 already saved. No downloads
except one small request for which stocks Alpaca lets you short today.

Shorting is where the worst losses live, because a stock can rise
without limit. So this shows borrow fee scenarios and the disaster
trades, not just the average.

New cell, same notebook. Add keys and run once.
"""

import json
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

ALPACA_KEY = "PASTE_PAPER_KEY_ID"
ALPACA_SECRET = "PASTE_PAPER_SECRET"
COST_PER_TRADE = 0.0020          # shorting thin stocks costs more to get in and out
HOLDS = [1, 3, 5, 10, 20]
BORROW_FEES = [0.05, 0.30, 1.00]  # yearly fee, easy to borrow vs hard vs very hard

ev = pd.read_csv("riptide5_events.csv", parse_dates=["day"]).drop_duplicates(["day", "sym"])
mk = pd.read_csv("riptide5_market.csv", parse_dates=["day"]).groupby("day").sum()
midx = (1 + (mk.ret_sum / mk.n.replace(0, np.nan)).fillna(0)).cumprod()

req = urllib.request.Request(
    "https://paper-api.alpaca.markets/v2/assets?status=active&asset_class=us_equity",
    headers={"APCA-API-KEY-ID": ALPACA_KEY, "APCA-API-SECRET-KEY": ALPACA_SECRET})
with urllib.request.urlopen(req, timeout=90) as r:
    assets = json.load(r)
etb = {a["symbol"] for a in assets if a.get("easy_to_borrow") and a.get("shortable")}


def short_pnl(e, h, fee):
    raw = e[f"exit_{h}"] / e["entry"] - 1
    m = midx.reindex(e.day).values
    m_end = midx.shift(-h).reindex(e.day).values
    hedged = -(raw - (m_end / m - 1)) - COST_PER_TRADE - fee * h / 252
    return hedged[np.isfinite(hedged)]


def tscore(x, days):
    by_day = x.groupby(days).mean()
    return by_day.mean() / by_day.std() * np.sqrt(len(by_day))


groups = {
    "all gaps": ev,
    "gap over 8 percent": ev[ev.gap >= 0.08],
    "over 8, easy to borrow now": ev[(ev.gap >= 0.08) & ev.sym.isin(etb)],
    "over 8, over $20M a day": ev[(ev.gap >= 0.08) & (ev.dollar_vol >= 2e7)],
}

print("SHORTING big gap ups, hedged, short from the gap day close")
print("t above about 2 is unlikely to be luck\n")
for name, g in groups.items():
    print(f"{name}  ({len(g)} events)")
    print("  hold   fee 5%/yr   fee 30%/yr  fee 100%/yr    t at 5%")
    for h in HOLDS:
        cells = []
        for fee in BORROW_FEES:
            p = short_pnl(g, h, fee)
            cells.append(f"{p.mean():+9.2%}")
        p5 = short_pnl(g, h, BORROW_FEES[0])
        print(f"  {h:>4}  " + "  ".join(cells) + f"   {tscore(p5, g.loc[p5.index, 'day']):+7.1f}")
    print()

g = groups["gap over 8 percent"]
p = short_pnl(g, 10, 0.30)
print("10 day short, gap over 8 percent, 30%/yr fee")
print(f"  win rate          {(p > 0).mean():.1%}")
print(f"  typical result    {p.median():+.2%}")
print(f"  worst 1 in 100    {p.quantile(0.01):+.1%}")
print(f"  worst ever        {p.min():+.1%}")
print("\n  the five worst")
for i in p.nsmallest(5).index:
    r = g.loc[i]
    print(f"    {r.day:%Y-%m-%d} {r.sym:<5} {p[i]:+.0%}")

print("\nby year, 10 day short, gap over 8, 30%/yr fee")
print((p.groupby(g.loc[p.index, "day"].dt.year).mean() * 100).round(2).astype(str).add("%").to_string())
print("\nSend all of this to Claude.")
