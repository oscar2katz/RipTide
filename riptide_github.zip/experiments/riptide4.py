"""
RIPTIDE v4, multi day drift after big gaps (part of Ocean Outlays)

When a stock gaps hard on heavy volume and holds that move all day,
research says it tends to keep drifting the same way for days or weeks.
This tests that on the daily prices v3 already saved, so no downloads.

The call is made at the end of the gap day
    UP    the stock gapped up, held it into the close, on big volume
    DOWN  same thing in the other direction
It tests buying at that close (decide around 2:45pm Chicago) or at the
next morning's open, and holding 1, 3, 5, 10 or 20 trading days.

"hedged" means the trade also bets against the average stock in the
list, so a market crash or rally mostly cancels out and only the
stock's own drift counts.

Run it in a new cell in the same notebook as v3. Takes under a minute.
"""

import numpy as np
import pandas as pd

GAP_MIN = 0.04            # opened at least 4 percent away from yesterday's close
VOLUME_MULT = 2.0         # volume at least 2 times its normal day
MIN_PRICE = 5.0
HOLDS = [1, 3, 5, 10, 20]
COST_PER_TRADE = 0.0010   # 0.10 percent in and out
BORROW_PER_YEAR = 0.05    # 5 percent a year fee for shorting
DAILY_FILE = "riptide3_daily.csv"

d = pd.read_csv(DAILY_FILE, parse_dates=["day"])
d = d.drop_duplicates(["day", "sym"])
O = d.pivot(index="day", columns="sym", values="o").sort_index()
C = d.pivot(index="day", columns="sym", values="c").reindex(O.index)
V = d.pivot(index="day", columns="sym", values="v").reindex(O.index)

prev_c = C.shift(1)
gap = O / prev_c - 1
day_move = C / prev_c - 1
avg_vol = V.rolling(20).mean().shift(1)

signal = ((gap.abs() >= GAP_MIN) & (V >= VOLUME_MULT * avg_vol) & (prev_c >= MIN_PRICE)
          & (np.sign(day_move) == np.sign(gap)) & (day_move.abs() >= GAP_MIN))
side = np.sign(gap).where(signal)

# the average stock in the list, used as the market for hedging
mkt = C.pct_change().mean(axis=1).fillna(0)
mkt_index = (1 + mkt).cumprod()


def results(entry_shift, hold):
    """entry_shift 0 buys at the gap day close, 1 buys at the next day's open.
    Either way the trade is closed at the close, hold trading days after the gap day."""
    entry_px = C if entry_shift == 0 else O.shift(-1)
    exit_px = C.shift(-hold)
    raw = exit_px / entry_px - 1
    m_ret = mkt_index.shift(-hold) / mkt_index - 1
    rows = []
    for (day, sym), s in side.stack().dropna().items():
        r = raw.at[day, sym]
        if not np.isfinite(r):
            continue
        borrow = BORROW_PER_YEAR * hold / 252 if s < 0 else 0
        pnl = s * r - COST_PER_TRADE - borrow
        hedged = s * (r - m_ret.at[day]) - COST_PER_TRADE - borrow
        rows.append((day, sym, int(s), pnl, hedged))
    return pd.DataFrame(rows, columns=["day", "sym", "side", "pnl", "hedged"])


def tscore(t, colname):
    # average same day trades together first so a busy day isn't counted many times
    by_day = t.groupby("day")[colname].mean()
    return by_day.mean() / by_day.std() * np.sqrt(len(by_day))


def table(entry_name, entry_shift):
    print(f"\nEntry at {entry_name}, after costs and short fees")
    print("hold side    trades   win   per trade  hedged   t hedged")
    keep = {}
    for h in HOLDS:
        t = results(entry_shift, h)
        keep[h] = t
        for s, name in ((1, "long "), (-1, "short")):
            x = t[t.side == s]
            if len(x) < 30:
                continue
            print(f"{h:>4} {name} {len(x):>8} {(x.pnl > 0).mean():6.1%} "
                  f"{x.pnl.mean():+9.2%} {x.hedged.mean():+8.2%} {tscore(x, 'hedged'):+8.1f}")
    return keep


print(f"Riptide v4, {O.index[0]:%b %Y} to {O.index[-1]:%b %Y}")
print(f"{int(signal.sum().sum())} gap days found across {O.shape[1]} stocks")
print("t above about 2 is unlikely to be luck")

close_res = table("the gap day close", 0)
open_res = table("the next morning open", 1)

t10 = close_res[10]
print("\n10 day hold from the close, hedged per trade by year")
yr = t10.groupby([t10.day.dt.year, t10.side.map({1: "long", -1: "short"})]).hedged.mean().unstack()
print((yr * 100).round(2).astype(str).add("%").to_string())

print("\nWorst single trades, 10 day hold, not hedged")
worst = t10.nsmallest(5, "pnl")
for _, w in worst.iterrows():
    print(f"  {w.day:%Y-%m-%d} {w.sym:<5} {'long' if w.side > 0 else 'short'}  {w.pnl:+.1%}")
print("\nSend all of this to Claude.")
