"""
RIPTIDE, end of day caller (part of Ocean Outlays)
Run a few minutes after the market opens (8:35am Chicago).
For each stock it says UP, DOWN or SKIP for today's close,
how much it expects the price to move from the open, and how
often that kind of call won in honest walk forward testing.

Works in Carnets on iPhone or regular Python. Needs only
pandas, numpy and scikit-learn, no extra installs.
Set BACKTEST below to True to test it on past data,
or False to get today's calls, then run the cell.
"""

import json
import urllib.request

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

BACKTEST = True            # True tests on the past, False gives today's calls
TICKERS = ["AAPL", "MSFT", "NVDA", "AMZN", "META", "GOOGL", "TSLA", "SPY", "QQQ"]
MIN_CONFIDENCE = 0.55      # below this the call is SKIP
COST_PER_TRADE = 0.0005    # 0.05 percent for slippage and spread
TRAIN_YEARS = 3            # how much history the model learns from each time
RETRAIN_EVERY = 21         # trading days between retrains in the backtest


def load(ticker, years=10):
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}"
           f"?range={years}y&interval=1d&events=split,div")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        res = json.load(r)["chart"]["result"][0]
    q = res["indicators"]["quote"][0]
    df = pd.DataFrame({"Open": q["open"], "High": q["high"], "Low": q["low"],
                       "Close": q["close"], "Volume": q["volume"]},
                      index=pd.to_datetime(res["timestamp"], unit="s").normalize())
    adj = res["indicators"].get("adjclose")
    if adj:  # adjust for splits and dividends so old prices line up
        factor = pd.Series(adj[0]["adjclose"], index=df.index) / df["Close"]
        for c in ("Open", "High", "Low", "Close"):
            df[c] = df[c] * factor
    df = df.dropna()
    return df[~df.index.duplicated(keep="last")]


def features(df, spy):
    """Everything here is known at the open, nothing peeks at the close."""
    f = pd.DataFrame(index=df.index)
    prev_close = df["Close"].shift(1)
    f["gap"] = df["Open"] / prev_close - 1
    for n in (1, 3, 5, 10, 20):
        f[f"ret_{n}"] = prev_close / df["Close"].shift(1 + n) - 1
    daily = df["Close"].pct_change()
    f["vol_10"] = daily.shift(1).rolling(10).std()
    f["vol_ratio"] = f["vol_10"] / daily.shift(1).rolling(60).std()
    f["range_prev"] = (df["High"] - df["Low"]).shift(1) / prev_close
    f["volu_ratio"] = df["Volume"].shift(1) / df["Volume"].shift(1).rolling(20).mean()
    f["dist_20ma"] = prev_close / df["Close"].shift(1).rolling(20).mean() - 1
    f["gap_vs_vol"] = f["gap"] / f["vol_10"]
    s_prev = spy["Close"].shift(1)
    f["spy_gap"] = (spy["Open"] / s_prev - 1).reindex(df.index)
    f["spy_ret_5"] = (s_prev / spy["Close"].shift(6) - 1).reindex(df.index)
    f["weekday"] = df.index.dayofweek
    target = df["Close"] / df["Open"] - 1   # open to close move, the thing we predict
    return f, target


def fit(X, y):
    clf = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.03,
                                         max_depth=3, l2_regularization=1.0)
    reg = HistGradientBoostingRegressor(max_iter=200, learning_rate=0.03,
                                        max_depth=3, l2_regularization=1.0)
    clf.fit(X, (y > 0).astype(int))
    reg.fit(X, y.abs())
    return clf, reg


def call(p_up, size):
    if p_up >= MIN_CONFIDENCE:
        return "UP", p_up, size
    if 1 - p_up >= MIN_CONFIDENCE:
        return "DOWN", 1 - p_up, -size
    return "SKIP", max(p_up, 1 - p_up), 0.0


def backtest(data, spy):
    rows = []
    for t, df in data.items():
        X, y = features(df, spy)
        ok = X.notna().all(axis=1) & y.notna()
        X, y = X[ok], y[ok]
        start = 252 * TRAIN_YEARS
        for i in range(start, len(X), RETRAIN_EVERY):
            tr = slice(i - start, i)              # only the past
            te = slice(i, min(i + RETRAIN_EVERY, len(X)))  # the unseen next month
            clf, reg = fit(X.iloc[tr], y.iloc[tr])
            p = clf.predict_proba(X.iloc[te])[:, 1]
            for d, pu, actual in zip(X.index[te], p, y.iloc[te]):
                side, conf, _ = call(pu, 0)
                if side == "SKIP":
                    continue
                sign = 1 if side == "UP" else -1
                rows.append({"date": d, "ticker": t, "side": side, "conf": conf,
                             "pnl": sign * actual - COST_PER_TRADE})
    res = pd.DataFrame(rows)
    if res.empty:
        print("No trades passed the confidence filter.")
        return res
    win = (res.pnl > 0).mean()
    avg_win = res.pnl[res.pnl > 0].mean()
    avg_loss = res.pnl[res.pnl <= 0].mean()
    print(f"\nWalk forward backtest, {len(res)} calls, after costs")
    print(f"win rate        {win:.1%}")
    print(f"avg win         {avg_win:+.2%}")
    print(f"avg loss        {avg_loss:+.2%}")
    print(f"expectancy      {res.pnl.mean():+.3%} per call")
    print(f"total if 1 unit per call   {res.pnl.sum():+.1%}")
    res["bucket"] = pd.cut(res.conf, [0.55, 0.58, 0.62, 1.0])
    print("\nby confidence")
    print(res.groupby("bucket", observed=True).pnl.agg(
        calls="count", win_rate=lambda s: (s > 0).mean(), expectancy="mean").to_string())
    print("\nby year")
    print(res.groupby(res.date.dt.year).pnl.agg(
        calls="count", win_rate=lambda s: (s > 0).mean(), total="sum").to_string())
    return res


def today(data, spy):
    print(f"\nRIPTIDE calls ({pd.Timestamp.now():%a %b %d})\n")
    for t, df in data.items():
        X, y = features(df, spy)
        ok = X.notna().all(axis=1)
        last = X[ok].iloc[[-1]]
        hist = ok & y.notna()
        Xh, yh = X[hist].iloc[:-1].tail(252 * TRAIN_YEARS), y[hist].iloc[:-1].tail(252 * TRAIN_YEARS)
        clf, reg = fit(Xh, yh)
        side, conf, move = call(clf.predict_proba(last)[0, 1], reg.predict(last)[0])
        open_px = df["Open"].iloc[-1]
        if side == "SKIP":
            print(f"{t:<6} SKIP")
        else:
            print(f"{t:<6} {side:<5} {move:+.2%}  to {open_px * (1 + move):.2f}   confidence {conf:.0%}")


def run():
    print("loading prices...")
    spy = load("SPY")
    data = {t: load(t) for t in TICKERS}
    if BACKTEST:
        backtest(data, spy)
    else:
        today(data, spy)


run()
