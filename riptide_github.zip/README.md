# Riptide

A daily trading strategy for the S&P 500, built by testing seven ideas honestly and keeping the one that held up.

On 1953 to 1992, years never used to build it, Riptide made about 14% a year versus 7.3% for holding the index. On 1993 to 2026 it made about 19% a year versus 11%, with a smaller worst drop.

## How it works

Each trading day Riptide checks two things about SPY.

1. **Trend.** Is SPY above its 200 day average?
2. **Signal.** Is it the turn of the month, the day before a holiday, or a sharp pullback in an uptrend?

| Market | Signal day | Quiet day |
| --- | --- | --- |
| Uptrend | UPRO, 3x | SPY, 1x |
| Downtrend | SPY, 1x | Cash |

## Folders

- `live` holds the daily paper trading script for Alpaca.
- `research` holds the backtests behind the final version, including the unseen 1953 to 1992 check.
- `experiments` holds the six strategies that failed, kept to show the process.

## Running it

Python 3 with pandas and NumPy. Add your own Alpaca paper trading keys where marked. Never commit real keys.

Paper trading only. This is a personal research project, not investment advice.

## Automatic daily runs

`.github/workflows/riptide.yml` runs Riptide on GitHub's servers every weekday, so no one has to remember. Add three repository secrets under Settings, Secrets and variables, Actions.

- `ALPACA_KEY` and `ALPACA_SECRET`, your Alpaca paper keys
- `NTFY_TOPIC`, your ntfy topic name for phone alerts

Each run's trades are saved to `live/riptide_auto_log.csv`.
