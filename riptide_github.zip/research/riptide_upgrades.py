"""
RIPTIDE UPGRADES, round 1 (part of Ocean Outlays)

Tests upgrades to the live Riptide (SPY signals, traded at 3x) on 30+
years of history, aimed at a higher ceiling with real emergency brakes.
Every rule uses standard settings picked in advance, not tuned to the
data, so a good result here is less likely to be a fluke.

    base           what Riptide Auto does now, 3x on every UP day
    crash switch   3x only while SPY is above its 200 day average,
                   1x when the market is in a downtrend
    crash skip     same, but sit out entirely in a downtrend
    calm brake     shrink the bet when the market is unusually jumpy,
                   aiming for steady risk instead of steady size
    cash interest  earn the Treasury bill rate on days in cash, which a
                   real brokerage money market fund would pay
    best combo     crash switch, calm brake and cash interest together

It also answers your doubling question, how often $1,000 became $2,000
within 3 and 5 years, starting from every possible day.

Free, no keys, under a minute. New cell, run once, send the output.
"""

import json
import time
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

START_MONEY = 1000
MAX_LEV = 3
FUND_FEE = 0.009
BORROW_RATE = 0.03
COST_PER_TRADE = 0.0003
RSI_BUY = 10
CALM_TARGET = 0.15          # aim for the market's normal yearly swing size
ERAS = [("1993", "2009"), ("2010", "2019"), ("2020", "2030")]


def load(sym):
    now = int(time.time())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}"
           f"?period1=0&period2={now}&interval=1d&events=div,split")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                res = json.load(r)["chart"]["result"][0]
            break
        except (OSError, ValueError):
            if attempt == 3:
                raise
            time.sleep(10)
    idx = pd.to_datetime(res["timestamp"], unit="s").normalize()
    c = pd.Series(res["indicators"]["quote"][0]["close"], index=idx)
    adj = res["indicators"].get("adjclose")
    if adj:
        c = pd.Series(adj[0]["adjclose"], index=idx)
    c = c.dropna()
    c = c[~c.index.duplicated(keep="last")]
    if len(c) < 2000 or pd.Series(c.index).diff().dt.days.median() > 3:
        raise RuntimeError(f"Yahoo didn't send daily prices for {sym}, try again in a minute")
    return c


def held_days(c):
    days = c.index
    nxt = pd.Series(days, index=days).shift(-1)
    last = (nxt.dt.month.ne(days.month) & nxt.notna()).values
    first3 = (pd.Series(1, index=days).groupby([days.year, days.month]).cumsum() <= 3).values
    gap = np.array([np.busday_count(a.date(), b.date()) if pd.notna(b) else 1 for a, b in zip(days, nxt)])
    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=0.5, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=0.5, adjust=False).mean()
    rsi2 = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, sma5 = c.rolling(200).mean(), c.rolling(5).mean()
    dip, inside = [], False
    for i in range(len(c)):
        dip.append(inside)
        if not inside and c.iloc[i] > sma200.iloc[i] and rsi2.iloc[i] < RSI_BUY:
            inside = True
        elif inside and c.iloc[i] > sma5.iloc[i]:
            inside = False
    return pd.Series(last | first3 | (gap > 1) | np.array(dip), index=days)


def simulate(r, held, lev, cash_rate):
    """lev is the leverage used on each held day, decided at the prior close."""
    lev = lev.where(held, 0.0)
    daily_cost = (FUND_FEE * (lev > 1) + BORROW_RATE * (lev - 1).clip(lower=0)) / 252
    changes = lev.diff().abs().fillna(lev)
    strat = lev * r - daily_cost - changes * COST_PER_TRADE
    strat = strat + cash_rate * (1 - lev.clip(upper=1))      # idle money earns interest
    return strat.clip(lower=-0.99)


def summarize(name, strat, idx_years):
    g = (1 + strat).cumprod()
    ann = g.iloc[-1] ** (1 / idx_years) - 1
    dd = (g / g.cummax() - 1).min()
    yearly = ((1 + strat).groupby(strat.index.year).prod() - 1).iloc[1:]
    gv = g.values
    dbl = {}
    for yrs in (3, 5):
        n = 252 * yrs
        hits = [np.any(gv[i + 1:i + n + 1] >= 2 * gv[i]) for i in range(0, len(gv) - n, 5)]
        dbl[yrs] = np.mean(hits)
    eras = []
    for a, b in ERAS:
        m = (strat.index >= a) & (strat.index <= f"{b}-12-31")
        s = strat[m]
        eras.append((1 + s).prod() ** (252 / max(len(s), 1)) - 1)
    print(f"{name:<14} {ann:+7.1%} {START_MONEY * ann:+7,.0f} {dd:9.0%} {yearly.min():+9.0%} "
          f"{(yearly < 0).mean():8.0%} {dbl[3]:9.0%} {dbl[5]:9.0%}   "
          + "  ".join(f"{e:+6.1%}" for e in eras))


print("RIPTIDE UPGRADES, round 1, SPY signals traded with leverage, after costs")
spy = load("SPY")
try:
    bill = load("^IRX").reindex(spy.index).ffill().fillna(0) / 100 / 252
except Exception as e:
    print(f"couldn't get Treasury bill rates ({e}), cash interest set to zero")
    bill = pd.Series(0.0, index=spy.index)

r = spy.pct_change().fillna(0)
held = held_days(spy)
years = len(r) / 252
uptrend = (spy > spy.rolling(200).mean()).shift(1, fill_value=False)
vol = r.rolling(20).std().shift(1) * np.sqrt(252)
calm = (CALM_TARGET / vol).clip(upper=1.0).fillna(1.0)
full = pd.Series(float(MAX_LEV), index=spy.index)
zero = pd.Series(0.0, index=spy.index)

variants = {
    "base": simulate(r, held, full, zero),
    "crash switch": simulate(r, held, full.where(uptrend, 1.0), zero),
    "crash skip": simulate(r, held, full.where(uptrend, 0.0), zero),
    "calm brake": simulate(r, held, full * calm, zero),
    "cash interest": simulate(r, held, full, bill),
    "best combo": simulate(r, held, (full * calm).where(uptrend, calm), bill),
}

print(f"{spy.index[0]:%Y} to {spy.index[-1]:%Y}, starting with ${START_MONEY:,}\n")
print("version        avg yr   $ a yr  worst drop  worst yr  losing yrs  "
      "doubled 3y doubled 5y   " + "  ".join(f"{a}-{b[2:]}" for a, b in ERAS))
for name, strat in variants.items():
    summarize(name, strat, years)
hold = r + 0
summarize("just hold SPY", hold, years)
print("\n'doubled 3y' is how often $1,000 reached $2,000 within 3 years, from any starting day.")
print("Send this to Claude.")
