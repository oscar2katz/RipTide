"""
RIPTIDE UPGRADES, round 3 (part of Ocean Outlays)

Round 2 showed Riptide's weak spot. In calm bull markets like 2013 to 2019
it sat in cash most days while SPY kept climbing. This tests staying
invested on quiet days while the market is in an uptrend, then stepping
up to 3x on Riptide's signal days, with the trend break as the brake.

    current       round 1 winner, 3x on signal days (1x in a downtrend),
                  cash with interest otherwise
    always on 1x  uptrend, 1x SPY on quiet days and 3x on signal days.
                  downtrend, cash on quiet days and 1x on signal days
    always on 2x  same, but 2x on quiet uptrend days, a higher ceiling
    trend only    no signals, just 1x SPY in an uptrend and cash in a
                  downtrend, a classic rule for comparison
    just hold     SPY all the time

Free, no keys, under a minute. New cell, run once, send the output.
"""

import json
import time
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

START_MONEY = 1000
FUND_FEE = 0.009
BORROW_RATE = 0.03
COST_PER_TRADE = 0.0003
RSI_BUY = 10
ERAS = [("1993", "2003"), ("2004", "2012"), ("2013", "2019"), ("2020", "2030")]


def load(sym):
    now = int(time.time())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}"
           f"?period1=0&period2={now}&interval=1d&events=div,split")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                res = json.load(r)["chart"]["result"][0]
            break
        except (OSError, ValueError):
            if attempt == 3:
                raise
            time.sleep(10)
    idx = pd.to_datetime(res["timestamp"], unit="s").normalize()
    c = pd.Series(res["indicators"]["quote"][0]["close"], index=idx)
    adj = res["indicators"].get("adjclose")
    if adj:
        c = pd.Series(adj[0]["adjclose"], index=idx)
    c = c.dropna()
    c = c[~c.index.duplicated(keep="last")]
    if len(c) < 2000 or pd.Series(c.index).diff().dt.days.median() > 3:
        raise RuntimeError(f"Yahoo didn't send daily prices for {sym}, try again in a minute")
    return c


def held_days(c):
    days = c.index
    nxt = pd.Series(days, index=days).shift(-1)
    last = (nxt.dt.month.ne(days.month) & nxt.notna()).values
    first3 = (pd.Series(1, index=days).groupby([days.year, days.month]).cumsum() <= 3).values
    gap = np.array([np.busday_count(a.date(), b.date()) if pd.notna(b) else 1 for a, b in zip(days, nxt)])
    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=0.5, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=0.5, adjust=False).mean()
    rsi2 = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, sma5 = c.rolling(200).mean(), c.rolling(5).mean()
    dip, inside = [], False
    for i in range(len(c)):
        dip.append(inside)
        if not inside and c.iloc[i] > sma200.iloc[i] and rsi2.iloc[i] < RSI_BUY:
            inside = True
        elif inside and c.iloc[i] > sma5.iloc[i]:
            inside = False
    return pd.Series(last | first3 | (gap > 1) | np.array(dip), index=days)


def simulate(r, lev, cash_rate):
    daily_cost = (FUND_FEE * (lev > 1) + BORROW_RATE * (lev - 1).clip(lower=0)) / 252
    changes = lev.diff().abs().fillna(lev)
    strat = lev * r - daily_cost - changes * COST_PER_TRADE + cash_rate * (1 - lev.clip(upper=1))
    return strat.clip(lower=-0.99)


def summarize(name, strat, trades_per_year):
    years = len(strat) / 252
    g = (1 + strat).cumprod()
    ann = g.iloc[-1] ** (1 / years) - 1
    dd = (g / g.cummax() - 1).min()
    yearly = ((1 + strat).groupby(strat.index.year).prod() - 1).iloc[1:]
    gv = g.values
    dbl = []
    for yrs in (3, 5):
        n = 252 * yrs
        dbl.append(np.mean([np.any(gv[i + 1:i + n + 1] >= 2 * gv[i]) for i in range(0, len(gv) - n, 5)]))
    eras = []
    for a, b in ERAS:
        m = (strat.index >= a) & (strat.index <= f"{b}-12-31")
        s = strat[m]
        eras.append((1 + s).prod() ** (252 / max(len(s), 1)) - 1)
    print(f"{name:<14} {ann:+7.1%} {START_MONEY * ann:+7,.0f} {dd:9.0%} {yearly.min():+9.0%} "
          f"{(yearly < 0).mean():8.0%} {dbl[0]:8.0%} {dbl[1]:8.0%} {trades_per_year:7.0f}   "
          + "  ".join(f"{e:+6.1%}" for e in eras))


print("RIPTIDE UPGRADES, round 3, staying invested in uptrends")
spy = load("SPY")
try:
    bill = load("^IRX").reindex(spy.index).ffill().fillna(0) / 100 / 252
except Exception:
    print("couldn't get Treasury bill rates, cash interest set to zero")
    bill = pd.Series(0.0, index=spy.index)

r = spy.pct_change().fillna(0)
sig = held_days(spy)
up = (spy > spy.rolling(200).mean()).shift(1, fill_value=False)
idx = spy.index
one = pd.Series(1.0, index=idx)


def lev_series(quiet_up, signal_up, quiet_down, signal_down):
    lev = pd.Series(0.0, index=idx)
    lev[up & sig] = signal_up
    lev[up & ~sig] = quiet_up
    lev[~up & sig] = signal_down
    lev[~up & ~sig] = quiet_down
    return lev


versions = {
    "current": lev_series(0, 3, 0, 1),
    "always on 1x": lev_series(1, 3, 0, 1),
    "always on 2x": lev_series(2, 3, 0, 1),
    "trend only": lev_series(1, 1, 0, 0),
}
years = len(idx) / 252
print(f"{idx[0]:%Y} to {idx[-1]:%Y}, starting with ${START_MONEY:,}, after costs, cash earns T bill interest\n")
print("version         avg yr   $ a yr  worst drop  worst yr  losing yrs  dbl 3y   dbl 5y  "
      "trades/yr   " + "  ".join(f"{a}-{b[2:]}" for a, b in ERAS))
for name, lev in versions.items():
    trades = (lev.diff().abs() > 0).sum() / years
    summarize(name, simulate(r, lev, bill), trades)
summarize("just hold SPY", r.copy(), 0)
print("\nSend this to Claude.")
