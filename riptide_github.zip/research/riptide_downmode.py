"""
RIPTIDE DOWN MODE TEST (part of Ocean Outlays)

Can Riptide profit when the market falls, without real shorting?
In a downtrend it would buy SH, an inverse S&P 500 fund that rises when
the market falls. You can never lose more than you put in, and it needs
no margin. Tested on BOTH histories, 1993 to 2026 and the unseen 1953 to
1992, and it only goes live if it wins on both.

    current        the live Riptide, always on 1x, cash on quiet downtrend days
    pop short      in a downtrend, hold SH after a sharp 2 day pop,
                   until the price falls back under its 5 day average
    trend short    in a downtrend, hold SH on every quiet day instead of cash

Free, no keys, under a minute. New cell, run once, send the output.
"""

import json
import time
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

FUND_FEE = 0.009
BORROW_EXTRA = 0.005
COST_PER_TRADE = 0.0003
RSI_BUY = 10


def load(sym, start=0):
    now = int(time.time())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}"
           f"?period1={start}&period2={now}&interval=1d&events=div,split")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                res = json.load(r)["chart"]["result"][0]
            break
        except (OSError, ValueError):
            if attempt == 3:
                raise
            time.sleep(10)
    idx = pd.to_datetime(res["timestamp"], unit="s").normalize()
    c = pd.Series(res["indicators"]["quote"][0]["close"], index=idx)
    adj = res["indicators"].get("adjclose")
    if adj:
        c = pd.Series(adj[0]["adjclose"], index=idx)
    c = c.dropna()
    c = c[~c.index.duplicated(keep="last")]
    c = c[c.index.dayofweek < 5]
    if pd.Series(c.index).diff().dt.days.median() > 3:
        raise RuntimeError(f"Yahoo didn't send daily prices for {sym}, try again in a minute")
    return c


def signals(c):
    days = c.index
    nxt = pd.Series(days, index=days).shift(-1)
    last = (nxt.dt.month.ne(days.month) & nxt.notna()).values
    first3 = (pd.Series(1, index=days).groupby([days.year, days.month]).cumsum() <= 3).values
    gap = np.array([np.busday_count(a.date(), b.date()) if pd.notna(b) else 1 for a, b in zip(days, nxt)])
    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=0.5, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=0.5, adjust=False).mean()
    rsi2 = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, sma5 = c.rolling(200).mean(), c.rolling(5).mean()
    dip, pop, in_dip, in_pop = [], [], False, False
    for i in range(len(c)):
        dip.append(in_dip)
        pop.append(in_pop)
        if not in_dip and c.iloc[i] > sma200.iloc[i] and rsi2.iloc[i] < RSI_BUY:
            in_dip = True
        elif in_dip and c.iloc[i] > sma5.iloc[i]:
            in_dip = False
        if not in_pop and c.iloc[i] < sma200.iloc[i] and rsi2.iloc[i] > 100 - RSI_BUY:
            in_pop = True
        elif in_pop and c.iloc[i] < sma5.iloc[i]:
            in_pop = False
    long_sig = pd.Series(last | first3 | (gap > 1) | np.array(dip), index=days)
    up_tr = (c > sma200).shift(1, fill_value=False)
    return long_sig, pd.Series(pop, index=days), up_tr


def simulate(r, lev, bill):
    """lev can be negative, -1 means holding SH."""
    size = lev.abs()
    borrow = (bill + BORROW_EXTRA / 252) * (size - 1).clip(lower=0)
    cost = FUND_FEE / 252 * ((lev > 1) | (lev < 0)) + borrow
    strat = lev * r - cost - lev.diff().abs().fillna(size) * COST_PER_TRADE + bill * (1 - size.clip(upper=1))
    return strat.clip(lower=-0.99)


def summarize(name, s):
    years = len(s) / 252
    g = (1 + s).cumprod()
    ann = g.iloc[-1] ** (1 / years) - 1
    dd = (g / g.cummax() - 1).min()
    yearly = (1 + s).groupby(s.index.year).prod() - 1
    gv = g.values
    n = 252 * 5
    dbl = np.mean([np.any(gv[i + 1:i + n + 1] >= 2 * gv[i]) for i in range(0, len(gv) - n, 5)])
    crash_years = [y for y in (1962, 1970, 1974, 1987, 2000, 2001, 2002, 2008, 2022) if y in yearly.index]
    crash = "  ".join(f"{y} {yearly[y]:+5.0%}" for y in crash_years)
    print(f"  {name:<13} {ann:+7.1%} {dd:9.0%} {yearly.min():+9.0%} {(yearly < 0).mean():8.0%} {dbl:7.0%}   {crash}")


def run(title, c, bill):
    r = c.pct_change().fillna(0)
    long_sig, pop, up = signals(c)
    lev_now = pd.Series(0.0, index=c.index)
    lev_now[up & long_sig], lev_now[up & ~long_sig], lev_now[~up & long_sig] = 3.0, 1.0, 1.0
    lev_pop = lev_now.copy()
    lev_pop[~up & ~long_sig & pop] = -1.0
    lev_trend = lev_now.copy()
    lev_trend[~up & ~long_sig] = -1.0
    print(f"\n{title}")
    print("  version        avg yr  worst drop  worst yr  losing yrs  dbl 5y   crash years")
    for name, lev in (("current", lev_now), ("pop short", lev_pop), ("trend short", lev_trend)):
        summarize(name, simulate(r, lev, bill))
    a, b = r[pop], r[~pop & ~up]
    se = np.sqrt(a.var() / len(a) + b.var() / len(b)) if len(a) > 5 and len(b) > 5 else 0
    t = (b.mean() - a.mean()) / se if se > 0 else np.nan
    print(f"  pop short days vs other downtrend days, avg {a.mean():+.3%} vs {b.mean():+.3%}, t {t:+.1f} "
          f"(positive t means pop days fell more, good for a short)")


print("RIPTIDE DOWN MODE TEST, after costs, cash earns T bill interest")
try:
    bill_all = load("^IRX", -1500000000) / 100 / 252
except Exception:
    bill_all = pd.Series(dtype=float)
spy = load("SPY")
spx = load("^GSPC", -1500000000)
spx = spx[(spx.index >= "1951-01-01")]


def bills(idx):
    b = bill_all.reindex(idx).ffill().bfill() if len(bill_all) else pd.Series(np.nan, index=idx)
    return b.fillna(0.04 / 252)


run(f"SPY {spy.index[0]:%Y} to {spy.index[-1]:%Y}, the history Riptide was built on", spy, bills(spy.index))
old = spx[(spx.index <= "1992-12-31")]
full = run("S&P 500 index 1951 to 1992, unseen, no dividends", old, bills(old.index))
print("\nA DOWN mode only goes live if it beats current on BOTH. Send this to Claude.")
