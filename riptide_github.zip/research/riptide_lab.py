"""
RIPTIDE, final form for now (part of Ocean Outlays)

Trades only big index funds (SPY, QQQ), so no single company can blow
you up, trading costs are tiny, and there are 30 years of free history.
It tests four documented short term timing patterns, each across three
different eras so a pattern that only worked long ago gets exposed,
then combines the ones that hold up into one daily call.

    turn of month   hold the last trading day of each month and the
                    first three of the next, when retirement money flows in
    pre holiday     hold the trading day right before a market holiday
    dip bounce      buy after a sharp short pullback while the long term
                    trend is up, sell once it bounces above its 5 day average
    overnight       hold only from the close to the next morning's open
    pop short       the DOWN side, bet against a sharp pop while the
                    long term trend is down, until it falls back

Free, no keys, one small download. Run it once for the full test and
today's call. For live calls run it around 2:40pm Chicago, since every
signal acts at the close.
"""

import json
import time
import urllib.request
from datetime import date

import numpy as np
import pandas as pd

TICKERS = ["SPY", "QQQ"]
COST_PER_TRADE = 0.0002     # in and out of SPY or QQQ, about 0.02 percent
RSI_BUY = 10                # dip bounce buys when 2 day RSI is below this
ERAS = [("1993", "2009"), ("2010", "2019"), ("2020", "2030")]

# market holidays, so live calls know when a pre holiday day is coming
HOLIDAYS = pd.to_datetime("""2026-01-01 2026-01-19 2026-02-16 2026-04-03 2026-05-25 2026-06-19
2026-07-03 2026-09-07 2026-11-26 2026-12-25 2027-01-01 2027-01-18 2027-02-15 2027-03-26
2027-05-31 2027-06-18 2027-07-05 2027-09-06 2027-11-25 2027-12-24""".split())


def load(sym):
    # asking for "max" makes Yahoo send monthly bars, so ask for an exact date range instead
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}"
           f"?period1=0&period2={int(time.time())}&interval=1d&events=div,split")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        res = json.load(r)["chart"]["result"][0]
    q = res["indicators"]["quote"][0]
    idx = pd.to_datetime(res["timestamp"], unit="s").normalize()
    df = pd.DataFrame({"o": q["open"], "c": q["close"]}, index=idx)
    adj = res["indicators"].get("adjclose")
    if adj:  # include dividends so returns are real
        f = pd.Series(adj[0]["adjclose"], index=idx) / df["c"]
        df = df.mul(f, axis=0)
    df = df.dropna()
    df = df[~df.index.duplicated(keep="last")]
    gap = pd.Series(df.index).diff().dt.days.median()
    if len(df) < 2000 or gap > 3:
        raise RuntimeError(f"Yahoo sent {len(df)} rows about {gap:.0f} days apart, not daily prices. Try again in a minute.")
    return df


def signals(df):
    """Each column is True on days whose close to close return the strategy collects.
    Every decision is made at the previous close, so nothing peeks ahead."""
    c = df["c"]
    days = df.index
    s = pd.DataFrame(index=days)

    nxt = pd.Series(days, index=days).shift(-1)
    last_of_month = nxt.dt.month.ne(days.month) & nxt.notna()
    pos_in_month = pd.Series(1, index=days).groupby([days.year, days.month]).cumsum()
    s["turn of month"] = last_of_month.values | (pos_in_month.values <= 3)

    gap_days = pd.Series([np.busday_count(a.date(), b.date()) if pd.notna(b) else 1
                          for a, b in zip(days, nxt)], index=days)
    s["pre holiday"] = (gap_days > 1).values      # a weekday is missing after this day

    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=0.5, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=0.5, adjust=False).mean()
    rsi2 = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, sma5 = c.rolling(200).mean(), c.rolling(5).mean()
    held, inside = [], False
    for i in range(len(c)):
        held.append(inside)                       # today's return belongs to yesterday's decision
        if not inside and c.iloc[i] > sma200.iloc[i] and rsi2.iloc[i] < RSI_BUY:
            inside = True
        elif inside and c.iloc[i] > sma5.iloc[i]:
            inside = False
    s["dip bounce"] = held
    s.attrs["dip_tomorrow"] = inside              # decision made at the latest close

    # the mirror image for betting DOWN, a sharp pop while the long term trend is down
    held, inside = [], False
    for i in range(len(c)):
        held.append(inside)
        if not inside and c.iloc[i] < sma200.iloc[i] and rsi2.iloc[i] > 100 - RSI_BUY:
            inside = True
        elif inside and c.iloc[i] < sma5.iloc[i]:
            inside = False
    s.attrs["pop_short"] = pd.Series(held, index=days)
    s.attrs["short_tomorrow"] = inside
    return s, rsi2, sma200, sma5


def stats(ret, inside, trades):
    """ret is every day's return, inside marks the days the strategy holds."""
    years = len(ret) / 252
    strat = ret.where(inside, 0.0)
    strat = strat - trades * COST_PER_TRADE
    growth = (1 + strat).cumprod()
    ann = growth.iloc[-1] ** (1 / years) - 1
    dd = (growth / growth.cummax() - 1).min()
    a, b = ret[inside], ret[~inside]
    se = np.sqrt(a.var() / len(a) + b.var() / len(b)) if len(a) > 5 and len(b) > 5 else 0
    t = (a.mean() - b.mean()) / se if se > 0 else np.nan
    return ann, inside.mean(), a.mean(), dd, t


def trade_flags(inside):
    """One round trip cost on each day a holding period starts."""
    return (inside & ~inside.shift(1, fill_value=False)).astype(float)


def report(sym, df):
    ret = df["c"].pct_change().fillna(0)
    s, rsi2, sma200, sma5 = signals(df)
    s["combined"] = s["turn of month"] | s["pre holiday"] | s["dip bounce"]
    overnight = (df["o"] / df["c"].shift(1) - 1).fillna(0)

    print(f"\n{sym}, {df.index[0]:%Y} to {df.index[-1]:%Y}, after costs")
    bh_ann = (1 + ret).prod() ** (252 / len(ret)) - 1
    bh_dd = ((1 + ret).cumprod() / (1 + ret).cumprod().cummax() - 1).min()
    print(f"just holding         {bh_ann:+6.1%} a year, worst drop {bh_dd:.0%}")
    print("strategy             per year  time in  avg held day  worst drop   t vs other days")
    for col in s.columns:
        ann, tin, avg, dd, t = stats(ret, s[col], trade_flags(s[col]))
        print(f"{col:<20} {ann:+8.1%} {tin:8.0%} {avg:+12.3%} {dd:11.0%} {t:+9.1f}")
    on = overnight - 2 * COST_PER_TRADE / 2
    g = (1 + on).cumprod()
    print(f"{'overnight':<20} {g.iloc[-1] ** (252 / len(on)) - 1:+8.1%} {1:8.0%} "
          f"{on.mean():+12.3%} {(g / g.cummax() - 1).min():11.0%}      n/a")

    sh = s.attrs["pop_short"]
    sret = -ret                                   # a short earns the opposite of the fund
    ann, tin, avg, dd, _ = stats(sret, sh, trade_flags(sh))
    a, b = ret[sh], ret[~sh]
    se = np.sqrt(a.var() / len(a) + b.var() / len(b)) if len(a) > 5 and len(b) > 5 else 0
    t = (b.mean() - a.mean()) / se if se > 0 else np.nan
    print(f"{'pop short (DOWN)':<20} {ann:+8.1%} {tin:8.0%} {avg:+12.3%} {dd:11.0%} {t:+9.1f}")
    print("by era, average held day versus an average day")
    print("strategy             " + "  ".join(f"{a}-{b[2:]:<4}" for a, b in ERAS))
    for col in s.columns:
        cells = []
        for a, b in ERAS:
            m = (df.index >= a) & (df.index <= f"{b}-12-31")
            r, ins = ret[m], s[col][m]
            cells.append(f"{r[ins].mean() - r.mean():+8.3%}" if ins.sum() > 10 else "     n/a")
        print(f"{col:<20} " + "  ".join(cells))
    cells = []
    for a, b in ERAS:
        m = (df.index >= a) & (df.index <= f"{b}-12-31")
        r, ins = ret[m], s.attrs["pop_short"][m]
        cells.append(f"{r.mean() - r[ins].mean():+8.3%}" if ins.sum() > 10 else "     n/a")
    print(f"{'pop short (DOWN)':<20} " + "  ".join(cells))
    return s, rsi2, sma200, sma5, ret


def todays_call(sym, df, s, rsi2, sma200, sma5, ret):
    today = df.index[-1]
    c = df["c"]
    nxt_day = pd.bdate_range(today + pd.Timedelta(days=1), periods=10)
    nxt_day = [d for d in nxt_day if d not in HOLIDAYS][0]
    reasons = []
    # turn of month, is the next trading day one of the held days
    after = [d for d in pd.bdate_range(nxt_day, periods=6) if d not in HOLIDAYS]
    if after[0].month != after[1].month or (sum(1 for d in pd.bdate_range(
            nxt_day.replace(day=1), nxt_day) if d not in HOLIDAYS) <= 3):
        reasons.append("turn of month")
    if nxt_day + pd.offsets.BDay(1) in HOLIDAYS:
        reasons.append("pre holiday")
    if s.attrs.get("dip_tomorrow"):
        was_in = bool(s["dip bounce"].iloc[-1])
        reasons.append("dip bounce, still waiting for the bounce" if was_in else "dip bounce, new signal")
    if reasons:
        held = s["combined"]
        avg = ret[held].mean()
        print(f"{sym:<4} UP     hold through {nxt_day:%a %b %d}, "
              f"typical held day {avg:+.2%}, to about {c.iloc[-1] * (1 + avg):.2f}   ({', '.join(reasons)})")
    elif s.attrs.get("short_tomorrow"):
        avg = ret[s.attrs["pop_short"]].mean()
        print(f"{sym:<4} DOWN   short or buy the inverse fund through {nxt_day:%a %b %d}, "
              f"typical held day {avg:+.2%}, to about {c.iloc[-1] * (1 + avg):.2f}   (pop short)")
    else:
        print(f"{sym:<4} SKIP   stay in cash tomorrow")


print("RIPTIDE, index fund timing")
print("t above about 2 means held days really beat other days, not luck")
results = {}
for sym in TICKERS:
    df = load(sym)
    results[sym] = (df, report(sym, df))

print(f"\nTODAY'S CALLS, act at the close, based on prices as of {date.today():%b %d}")
for sym, (df, (s, rsi2, sma200, sma5, ret)) in results.items():
    todays_call(sym, df, s, rsi2, sma200, sma5, ret)
print("\nSend the full output to Claude before trading any of it.")
