"""
RIPTIDE BOOST, what happens if Riptide uses 2x or 3x funds on its UP days

Same signals as Riptide (turn of month, pre holiday, dip bounce), but on
held days it uses a leveraged fund, SSO or UPRO for SPY, QLD or TQQQ for
QQQ. Those multiply each day's move. This shows the average year AND the
bad years, in dollars on $1,000, so the tradeoff is clear.

Leveraged funds charge fees and borrowing costs, which are included.
QQQ includes the 2000 to 2002 crash, a brutal test for leverage.

Free, no keys, under a minute. New cell, run once.
"""

import json
import time
import urllib.request

import numpy as np
import pandas as pd

START_MONEY = 1000
LEVERAGE = [1, 2, 3]
FUND_FEE = 0.009            # leveraged funds charge about 0.9 percent a year
BORROW_RATE = 0.03          # what the fund pays to borrow for the extra leverage
COST_PER_TRADE = 0.0003
RSI_BUY = 10


def load(sym):
    now = int(time.time())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}"
           f"?period1=0&period2={now}&interval=1d&events=div,split")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        res = json.load(r)["chart"]["result"][0]
    idx = pd.to_datetime(res["timestamp"], unit="s").normalize()
    c = pd.Series(res["indicators"]["quote"][0]["close"], index=idx)
    adj = res["indicators"].get("adjclose")
    if adj:
        c = pd.Series(adj[0]["adjclose"], index=idx)
    c = c.dropna()
    c = c[~c.index.duplicated(keep="last")]
    if len(c) < 2000 or pd.Series(c.index).diff().dt.days.median() > 3:
        raise RuntimeError("Yahoo didn't send daily prices, try again in a minute")
    return c


def held_days(c):
    days = c.index
    nxt = pd.Series(days, index=days).shift(-1)
    last = (nxt.dt.month.ne(days.month) & nxt.notna()).values
    first3 = (pd.Series(1, index=days).groupby([days.year, days.month]).cumsum() <= 3).values
    gap = np.array([np.busday_count(a.date(), b.date()) if pd.notna(b) else 1 for a, b in zip(days, nxt)])
    pre_holiday = gap > 1
    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=0.5, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=0.5, adjust=False).mean()
    rsi2 = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, sma5 = c.rolling(200).mean(), c.rolling(5).mean()
    dip, inside = [], False
    for i in range(len(c)):
        dip.append(inside)
        if not inside and c.iloc[i] > sma200.iloc[i] and rsi2.iloc[i] < RSI_BUY:
            inside = True
        elif inside and c.iloc[i] > sma5.iloc[i]:
            inside = False
    return pd.Series(last | first3 | pre_holiday | np.array(dip), index=days)


def run(sym):
    c = load(sym)
    r = c.pct_change().fillna(0)
    held = held_days(c)
    starts = (held & ~held.shift(1, fill_value=False)).astype(float)
    years = len(r) / 252
    print(f"\n{sym} based, {c.index[0]:%Y} to {c.index[-1]:%Y}, starting with ${START_MONEY:,}")
    print("leverage   avg year   avg $ a year   worst drop   worst year   losing years   $ after worst year")
    for L in LEVERAGE:
        daily_cost = (FUND_FEE + BORROW_RATE * (L - 1)) / 252 if L > 1 else 0
        strat = (L * r - daily_cost).where(held, 0.0) - starts * COST_PER_TRADE * L
        strat = strat.clip(lower=-0.99)
        g = (1 + strat).cumprod()
        ann = g.iloc[-1] ** (1 / years) - 1
        dd = (g / g.cummax() - 1).min()
        yearly = (1 + strat).groupby(strat.index.year).prod() - 1
        yearly = yearly.iloc[1:]       # skip the partial first year
        print(f"{L}x {'':<6} {ann:+8.1%} {START_MONEY * ann:+12,.0f} {dd:12.0%} {yearly.min():+11.0%}"
              f" {(yearly < 0).mean():13.0%} {START_MONEY * (1 + yearly.min()):17,.0f}")
    hold_ann = (1 + r).prod() ** (1 / years) - 1
    print(f"just holding {sym} all the time, {hold_ann:+.1%} a year, ${START_MONEY * hold_ann:+,.0f}")


print("RIPTIDE BOOST, same calls, bigger bets")
for sym in ["SPY", "QQQ"]:
    run(sym)
print("\nSend this to Claude.")
