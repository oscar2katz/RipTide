"""
RIPTIDE UPGRADES, round 2 (part of Ocean Outlays)

Riptide sits in cash about 70 percent of the time. This tests whether
other markets, each with its own separate ups and downs, can put that
idle money to work using the same proven rules.

Part 1 checks each fund on its own, 1x, same rules as Riptide
(turn of month, pre holiday, dip bounce):
    QQQ  big tech        IWM  small companies
    TLT  long term US government bonds
    GLD  gold

Part 2 builds the upgraded Riptide. SPY with the crash switch still comes
first. On days it's in cash, the money goes to any extra fund whose
signal is active and that passed Part 1, split evenly. Compared with
round 1's winner over the same years, including doubling odds.

Free, no keys, about a minute. New cell, run once, send the output.
"""

import json
import time
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

START_MONEY = 1000
EXTRAS = ["QQQ", "IWM", "TLT", "GLD"]
PASS_T = 2.0               # an extra fund must clear this to be used in Part 2
MAX_LEV = 3
FUND_FEE = 0.009
BORROW_RATE = 0.03
COST_PER_TRADE = 0.0003
RSI_BUY = 10
ERAS = [("2004", "2012"), ("2013", "2019"), ("2020", "2030")]


def load(sym):
    now = int(time.time())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}"
           f"?period1=0&period2={now}&interval=1d&events=div,split")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                res = json.load(r)["chart"]["result"][0]
            break
        except (OSError, ValueError):
            if attempt == 3:
                raise
            time.sleep(10)
    idx = pd.to_datetime(res["timestamp"], unit="s").normalize()
    c = pd.Series(res["indicators"]["quote"][0]["close"], index=idx)
    adj = res["indicators"].get("adjclose")
    if adj:
        c = pd.Series(adj[0]["adjclose"], index=idx)
    c = c.dropna()
    c = c[~c.index.duplicated(keep="last")]
    if len(c) < 1500 or pd.Series(c.index).diff().dt.days.median() > 3:
        raise RuntimeError(f"Yahoo didn't send daily prices for {sym}, try again in a minute")
    return c


def held_days(c):
    days = c.index
    nxt = pd.Series(days, index=days).shift(-1)
    last = (nxt.dt.month.ne(days.month) & nxt.notna()).values
    first3 = (pd.Series(1, index=days).groupby([days.year, days.month]).cumsum() <= 3).values
    gap = np.array([np.busday_count(a.date(), b.date()) if pd.notna(b) else 1 for a, b in zip(days, nxt)])
    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=0.5, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=0.5, adjust=False).mean()
    rsi2 = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, sma5 = c.rolling(200).mean(), c.rolling(5).mean()
    dip, inside = [], False
    for i in range(len(c)):
        dip.append(inside)
        if not inside and c.iloc[i] > sma200.iloc[i] and rsi2.iloc[i] < RSI_BUY:
            inside = True
        elif inside and c.iloc[i] > sma5.iloc[i]:
            inside = False
    return pd.Series(last | first3 | (gap > 1) | np.array(dip), index=days)


def tstat(r, held):
    a, b = r[held], r[~held]
    se = np.sqrt(a.var() / len(a) + b.var() / len(b)) if len(a) > 5 and len(b) > 5 else 0
    return (a.mean() - b.mean()) / se if se > 0 else np.nan


def summarize(name, strat):
    years = len(strat) / 252
    g = (1 + strat).cumprod()
    ann = g.iloc[-1] ** (1 / years) - 1
    dd = (g / g.cummax() - 1).min()
    yearly = ((1 + strat).groupby(strat.index.year).prod() - 1).iloc[1:]
    gv = g.values
    dbl = []
    for yrs in (3, 5):
        n = 252 * yrs
        dbl.append(np.mean([np.any(gv[i + 1:i + n + 1] >= 2 * gv[i]) for i in range(0, len(gv) - n, 5)]))
    eras = []
    for a, b in ERAS:
        m = (strat.index >= a) & (strat.index <= f"{b}-12-31")
        s = strat[m]
        eras.append((1 + s).prod() ** (252 / max(len(s), 1)) - 1)
    print(f"{name:<22} {ann:+7.1%} {START_MONEY * ann:+7,.0f} {dd:9.0%} {yearly.min():+9.0%} "
          f"{(yearly < 0).mean():8.0%} {dbl[0]:9.0%} {dbl[1]:9.0%}   "
          + "  ".join(f"{e:+6.1%}" for e in eras))


print("RIPTIDE UPGRADES, round 2, putting idle cash to work")
spy = load("SPY")
try:
    bill = load("^IRX").reindex(spy.index).ffill().fillna(0) / 100 / 252
except Exception:
    bill = pd.Series(0.0, index=spy.index)

print("\nPART 1, each extra fund alone at 1x, same rules as Riptide")
print("fund   years       held  avg held day  avg other day     t   " +
      "  ".join(f"{a}-{b[2:]}" for a, b in ERAS))
extras = {}
for sym in EXTRAS:
    try:
        c = load(sym)
    except Exception as e:
        print(f"{sym:<5} couldn't load ({e})")
        continue
    r = c.pct_change().fillna(0)
    h = held_days(c)
    t = tstat(r, h)
    eras = []
    for a, b in ERAS:
        m = (r.index >= a) & (r.index <= f"{b}-12-31")
        rr, hh = r[m], h[m]
        eras.append(f"{rr[hh].mean() - rr[~hh].mean():+7.3%}" if hh.sum() > 10 else "    n/a")
    ok = t >= PASS_T and all(not e.strip().startswith("-") for e in eras[-1:])
    print(f"{sym:<5} {c.index[0]:%Y}-{c.index[-1]:%y}  {h.mean():6.0%} {r[h].mean():+12.3%} "
          f"{r[~h].mean():+14.3%} {t:+6.1f}   " + "  ".join(eras) + ("   PASS" if ok else ""))
    if ok:
        extras[sym] = (r, h)

# Part 2, everything aligned to the years all chosen funds share
start = max([spy.index[0]] + [r.index[0] for r, _ in extras.values()] + [pd.Timestamp("2004-12-01")])
idx = spy.index[spy.index >= start]
r_spy = spy.pct_change().fillna(0).reindex(idx)
h_spy = held_days(spy).reindex(idx).fillna(False)
uptrend = (spy > spy.rolling(200).mean()).shift(1, fill_value=False).reindex(idx).fillna(False)
lev = pd.Series(float(MAX_LEV), index=idx).where(uptrend, 1.0).where(h_spy, 0.0)
cash = bill.reindex(idx).fillna(0)


def riptide(use_extras):
    daily_cost = (FUND_FEE * (lev > 1) + BORROW_RATE * (lev - 1).clip(lower=0)) / 252
    strat = lev * r_spy - daily_cost - lev.diff().abs().fillna(lev) * COST_PER_TRADE
    idle = ~h_spy
    extra_ret = pd.Series(0.0, index=idx)
    n_active = pd.Series(0, index=idx)
    for sym, (r, h) in use_extras.items():
        rr, hh = r.reindex(idx).fillna(0), h.reindex(idx).fillna(False) & idle
        extra_ret += rr.where(hh, 0.0)
        n_active += hh.astype(int)
        starts = hh & ~hh.shift(1, fill_value=False)
        extra_ret -= starts * COST_PER_TRADE
    in_extra = n_active > 0
    avg_extra = (extra_ret / n_active.replace(0, np.nan)).fillna(0)
    strat = strat + avg_extra.where(idle, 0.0)
    strat = strat + cash.where(idle & ~in_extra, 0.0)   # truly idle money earns interest
    return strat.clip(lower=-0.99), (h_spy | in_extra).mean()


print(f"\nPART 2, upgraded Riptide, {idx[0]:%Y} to {idx[-1]:%Y}, starting with ${START_MONEY:,}")
print("version                 avg yr   $ a yr  worst drop  worst yr  losing yrs  "
      "doubled 3y doubled 5y   " + "  ".join(f"{a}-{b[2:]}" for a, b in ERAS))
base, t_in = riptide({})
summarize("round 1 winner", base)
if extras:
    up, t_up = riptide(extras)
    summarize("plus " + "+".join(extras), up)
    print(f"\ntime with money working, round 1 {t_in:.0%}, upgraded {t_up:.0%}")
else:
    print("no extra fund passed Part 1, so round 1's version stays")
summarize("just hold SPY", r_spy)
print("\nSend this to Claude.")
