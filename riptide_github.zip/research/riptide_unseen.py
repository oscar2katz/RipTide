"""
RIPTIDE UNSEEN, the honesty check (part of Ocean Outlays)

Every Riptide choice so far was made using 1993 to 2026. This runs the
exact live rules, unchanged, on 1953 to 1992, years Riptide never saw.
It uses the S&P 500 index itself, since SPY didn't exist yet.

To be fair to the past
    leverage costs follow the interest rates of each era, which were
    sky high in the 1970s and 80s, so 3x was much more expensive then
    the index here leaves out dividends, for both Riptide and holding,
    so compare them to each other, not to today's numbers
    3x funds didn't exist yet, so this is what they would have done

Free, no keys, under a minute. New cell, run once, send the output.
"""

import json
import time
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

START, END = "1953-01-01", "1992-12-31"
START_MONEY = 1000
FUND_FEE = 0.009
BORROW_EXTRA = 0.005       # leveraged funds borrow at about the T bill rate plus this
COST_PER_TRADE = 0.0005
RSI_BUY = 10
ERAS = [("1953", "1972"), ("1973", "1982"), ("1983", "1992")]


def load(sym):
    now = int(time.time())
    url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(sym)}"
           f"?period1=-1500000000&period2={now}&interval=1d")
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                res = json.load(r)["chart"]["result"][0]
            break
        except (OSError, ValueError):
            if attempt == 3:
                raise
            time.sleep(10)
    idx = pd.to_datetime(res["timestamp"], unit="s").normalize()
    c = pd.Series(res["indicators"]["quote"][0]["close"], index=idx).dropna()
    c = c[~c.index.duplicated(keep="last")]
    if pd.Series(c.index).diff().dt.days.median() > 3:
        raise RuntimeError(f"Yahoo didn't send daily prices for {sym}, try again in a minute")
    return c


def held_days(c):
    days = c.index
    nxt = pd.Series(days, index=days).shift(-1)
    last = (nxt.dt.month.ne(days.month) & nxt.notna()).values
    first3 = (pd.Series(1, index=days).groupby([days.year, days.month]).cumsum() <= 3).values
    gap = np.array([np.busday_count(a.date(), b.date()) if pd.notna(b) else 1 for a, b in zip(days, nxt)])
    delta = c.diff()
    up = delta.clip(lower=0).ewm(alpha=0.5, adjust=False).mean()
    dn = (-delta.clip(upper=0)).ewm(alpha=0.5, adjust=False).mean()
    rsi2 = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    sma200, sma5 = c.rolling(200).mean(), c.rolling(5).mean()
    dip, inside = [], False
    for i in range(len(c)):
        dip.append(inside)
        if not inside and c.iloc[i] > sma200.iloc[i] and rsi2.iloc[i] < RSI_BUY:
            inside = True
        elif inside and c.iloc[i] > sma5.iloc[i]:
            inside = False
    return pd.Series(last | first3 | (gap > 1) | np.array(dip), index=days)


def simulate(r, lev, bill):
    borrow = (bill + BORROW_EXTRA / 252) * (lev - 1).clip(lower=0)
    cost = FUND_FEE / 252 * (lev > 1) + borrow
    strat = lev * r - cost - lev.diff().abs().fillna(lev) * COST_PER_TRADE + bill * (1 - lev.clip(upper=1))
    return strat.clip(lower=-0.99)


def summarize(name, strat):
    years = len(strat) / 252
    g = (1 + strat).cumprod()
    ann = g.iloc[-1] ** (1 / years) - 1
    dd = (g / g.cummax() - 1).min()
    yearly = (1 + strat).groupby(strat.index.year).prod() - 1
    gv = g.values
    n = 252 * 5
    dbl = np.mean([np.any(gv[i + 1:i + n + 1] >= 2 * gv[i]) for i in range(0, len(gv) - n, 5)])
    eras = []
    for a, b in ERAS:
        m = (strat.index >= a) & (strat.index <= f"{b}-12-31")
        s = strat[m]
        eras.append((1 + s).prod() ** (252 / max(len(s), 1)) - 1)
    print(f"{name:<15} {ann:+7.1%} {dd:9.0%} {yearly.min():+9.0%} {(yearly < 0).mean():8.0%} "
          f"{dbl:8.0%}   " + "  ".join(f"{e:+6.1%}" for e in eras))
    return strat


print("RIPTIDE UNSEEN, live rules on 1953 to 1992, years never used to build it")
spx_all = load("^GSPC")
try:
    bill_all = load("^IRX") / 100 / 252
except Exception:
    bill_all = pd.Series(dtype=float)
    print("couldn't get Treasury bill rates, using 4 percent a year")

spx_all = spx_all[spx_all.index >= "1951-01-01"]
spx_all = spx_all[spx_all.index.dayofweek < 5]          # the market traded Saturdays until 1952
sig_all = held_days(spx_all)
up_all = (spx_all > spx_all.rolling(200).mean()).shift(1, fill_value=False)

m = (spx_all.index >= START) & (spx_all.index <= END)
spx, sig, up = spx_all[m], sig_all[m], up_all[m]
r = spx.pct_change().fillna(0)
bill = bill_all.reindex(spx.index).ffill().bfill() if len(bill_all) else pd.Series(0.04 / 252, index=spx.index)
bill = bill.fillna(0.04 / 252)

lev_live = pd.Series(0.0, index=spx.index)
lev_live[up & sig], lev_live[up & ~sig], lev_live[~up & sig] = 3.0, 1.0, 1.0
lev_old = pd.Series(0.0, index=spx.index)
lev_old[up & sig], lev_old[~up & sig] = 3.0, 1.0

print(f"\n{spx.index[0]:%Y} to {spx.index[-1]:%Y}, S&P 500 price index, no dividends, after costs\n")
print("version          avg yr  worst drop  worst yr  losing yrs  dbl 5y   " +
      "  ".join(f"{a}-{b[2:]}" for a, b in ERAS))
live = summarize("Riptide now", simulate(r, lev_live, bill))
summarize("Riptide before", simulate(r, lev_old, bill))
summarize("just hold index", r.copy())

sig_r = r[sig.reindex(r.index).fillna(False)]
oth_r = r[~sig.reindex(r.index).fillna(False)]
se = np.sqrt(sig_r.var() / len(sig_r) + oth_r.var() / len(oth_r))
print(f"\nSignal days vs other days, avg {sig_r.mean():+.3%} vs {oth_r.mean():+.3%}, "
      f"t {(sig_r.mean() - oth_r.mean()) / se:+.1f}")

print("\nThe 5 worst days for Riptide now")
for d, v in live.nsmallest(5).items():
    print(f"  {d:%Y-%m-%d}  {v:+.1%}   index that day {r[d]:+.1%}   held {lev_live[d]:.0f}x")
print("\nSend this to Claude.")
